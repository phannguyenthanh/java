$(document).ready(function () {
    if ($.cookie("UserInfo") !== undefined) {
        var userInfo = JSON.parse($.cookie("UserInfo"));
        $("#app-nav-side-user-name").text(userInfo.name == null ? "..." : userInfo.name);
        $("#app-nav-side-user-date-of-birth").text(userInfo.dateOfBirth == null ? "..." : DonexApp.Utils.timestampToShortDateString(userInfo.dateOfBirth));
        if (userInfo.avatarId != undefined && userInfo.avatarId != null && userInfo.avatarId.length > 0) {
            $("#app-nav-side-avatar").attr("src", DonexApp.Api.Constants.API_IMAGE_URL + userInfo.avatarId);
        }
        $("#app-menu-item-logout").click(function () {
            DonexApp.Control.showLoading();
            DonexApp.Api.logout(
                function (data) {
                },
                function (data) {
                },
                function () {
                    DonexApp.Control.hideLoading();
                    window.location = "login.jsp";
                });
            return false;
        });
    }
});