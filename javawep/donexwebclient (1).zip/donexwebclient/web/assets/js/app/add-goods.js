$(document).ready(function () {
    
    /** Chỉnh sửa chút input **/
    var removeTag = function () {
        $(this).parent().remove();
    };

    // Nhấn nút thêm group tag
    $("#input-goods-add-group-tag-button").unbind().click(function () {
        var $inputGroupTag = $("#input-goods-group-tag");
        var inputTagString = $.trim($inputGroupTag.val());
        if (inputTagString != "") {
            inputTagString = DonexApp.Utils.upperCaseBeginning(inputTagString);
            $inputGroupTag.val(inputTagString);

            var isExisted = false;
            $("#list-goods-group-tag").find(".app-tag").each(function (index, tagObject) {
                if ($(tagObject).attr("value") == inputTagString) {
                    isExisted = true;
                    return false;
                }
            });

            if (isExisted) {
                DonexApp.Control.showOkDialog("Đã có group này rồi!", function () {
                    $inputGroupTag.select();
                });
            } else {
                var $tag = DonexApp.Control.makeTag(inputTagString, removeTag);
                $tag.attr("value", inputTagString);
                $("#list-goods-group-tag").append($tag);
            }
        }
    });
    
    
    // Bắt đầu tải lên thông tin
    var uploadAvatar = function (goodsId, inputFile) {
        DonexApp.Api.uploadGoodsAvatar(goodsId, inputFile,
            function (data) {
                if (data.code == DonexApp.Api.RESPONSE_CODE.SUCCESS) {
                    DonexApp.Control.showOkDialog("Đã thêm sản phẩm vào danh mục!", function () {
                        window.location.reload();
                    });
                } else {
                    DonexApp.Control.showOkDialog("Đã thêm sản phẩm vào danh mục! Tuy nhiên ảnh sản phẩm chưa được cập nhật.", function () {
                        window.location.reload();
                    });
                }
            },
            function () {
                DonexApp.Control.showOkDialog("Đã thêm sản phẩm vào danh mục! Tuy nhiên ảnh sản phẩm chưa được cập nhật.", function () {
                    window.location.reload();
                });
            },
            function () {
                DonexApp.Control.hideLoading();
            }
        );
    };
    $("#input-submit-add").click(function () {
        try {

            // Validate
            if ($.trim($("#input-goods-id").val()) == "") {
                DonexApp.Control.showRedOkDialog("Mã sản phẩm không được bỏ trống", function () {
                    $("#input-goods-id").focus();
                });
                return false;
            }

            DonexApp.Control.showLoading();
            $("#app-alert-box").hide();

            var goods = {};

            goods.goodsId = $("#input-goods-id").val();
            goods.name = $("#input-goods-name").val();
            goods.unit = $("#input-goods-unit").val();
            goods.price = $("#input-goods-price").val();

            goods.category = [];
            var groupTag = [];
            $("#list-goods-group-tag").find(".app-tag").each(function (index, appTag) {
                groupTag.push($(appTag).attr("value"));
            });
            if (groupTag.length > 0) {
                goods.category = groupTag;
            } else {
                goods.category = null;
            }

            goods.color = $("#input-goods-color").val();
            goods.sizes = [];
            $(".app-goods-size:checked").each(function (index, input) {
                goods.sizes.push($(input).val());
            });

            $.each(goods, function (key, value) {
                if (key != "sizes" && key != "category") {
                    if (value != null) {
                        if ($.trim(value).length == 0) {
                            goods[key] = null;
                        } else {
                            goods[key] = $.trim(value);
                        }
                    }
                }
            });

            DonexApp.Api.addGoods(goods,
                function (data) {
                    if (data.code == DonexApp.Api.RESPONSE_CODE.SUCCESS) {
                        var inputFile = $("#input-goods-avatar");
                        if (inputFile.value != "") {
                            uploadAvatar(goods.goodsId, inputFile[0]);
                        } else {
                            DonexApp.Control.showOkDialog("Đã thêm sản phẩm vào danh mục!", function () {
                                window.location.reload();
                            });
                        }
                    } else if (data.code == DonexApp.Api.RESPONSE_CODE.EXISTED) {
                        DonexApp.Control.hideLoading();
                        $("#app-alert-box").text("Đã tồn sản phẩm với mã " + goods.goodsId + " trong cơ sở dữ liệu. Mời bạn sử dụng mã khác.").show();
                    }
                },
                function () {
                    DonexApp.Control.hideLoading();
                    $("#app-alert-box").text("Có lỗi xảy ra. Vui lòng thử lại sau.").show();
                },
                function () {
                });
        } catch (ex) {
            console.log(ex);
        }
        return false;
    });
});