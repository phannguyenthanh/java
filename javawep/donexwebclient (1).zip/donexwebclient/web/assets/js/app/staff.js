$(document).ready(function () {
    /******************************** MÀN HÌNH THÔNG TIN NHÂN VIÊN ********************************/
    var showStaffInfo = function () {
        var staffId = $(this).attr("staffId");

        if (window.STAFF_INFO_SCREEN === undefined) {
            window.STAFF_INFO_SCREEN = {};
        }
        window.STAFF_INFO_SCREEN.staffId = staffId;

        var staff = window.staffMap[staffId];
        if (staff !== undefined) {
            $("#app-staff-info-name").text(staff.name == null ? "" : staff.name);
            if (staff.dateOfBirth != null) {
                $("#app-staff-info-date-of-birth").text(DonexApp.Utils.timestampToShortDateString(staff.dateOfBirth));
                var today = new Date();
                $("#app-staff-info-age").text(today.getFullYear() - new Date(staff.dateOfBirth).getFullYear() + 1);
            }
            if (staff.level !== undefined && staff.level != null && window.levelMap[staff.level] !== undefined) {
                $("#app-staff-info-level").text(window.levelMap[staff.level].levelName);
            }
            $("#app-staff-info-mobile").text(staff.mobile == null ? "" : staff.mobile);
            $("#app-staff-info-alternative-mobile").text(staff.alternativeMobile == null ? "" : staff.alternativeMobile);
            $("#app-staff-info-email").text(staff.email == null ? "" : staff.email);
            $("#app-staff-info-cmnd").text(staff.cmnd == null ? "" : staff.cmnd);
            $("#app-staff-info-permanent-address").text(staff.permanentAddress == null ? "" : staff.permanentAddress);
            $("#app-staff-info-living-address").text(staff.livingAddress == null ? "" : staff.livingAddress);
            $("#app-staff-info-start-working-date").text(staff.startWorkingDate == null ? "" : DonexApp.Utils.timestampToShortDateString(staff.startWorkingDate));
            $("#app-staff-info-end-working-date").text(staff.endWorkingDate == null ? "" : DonexApp.Utils.timestampToShortDateString(staff.endWorkingDate));
            if (staff.employmentStatus !== null) {
                $("#app-staff-info-employment-status").text(DonexApp.Api.EMPLOYMENT_STATUS_MAP[staff.employmentStatus]);
            } else {
                $("#app-staff-info-employment-status").text("");
            }

            var groupTag = "";
            if ($.isArray(staff.groupTag)) {
                $(staff.groupTag).each(function (index, value) {
                    groupTag += "#" + value + " ";
                });
            }
            $("#app-staff-info-group-tag").text(groupTag);

            var superiorStaffName = "";
            if (staff.superiorStaffId != null) {
                if (window.staffMap[staff.superiorStaffId] !== undefined) {
                    superiorStaffName = "(" + staff.superiorStaffId + ") " + window.staffMap[staff.superiorStaffId].name;
                }
            }
            $("#app-staff-info-superior-staff-id").text(superiorStaffName);

            if (staff.avatarId != null) {
                $("#app-staff-info-avatar").attr("src", DonexApp.Api.Constants.API_IMAGE_URL + staff.avatarId);
            } else {
                $("#app-staff-info-avatar").attr("src", "assets/img/app/missing-avatar.jpg");
            }
        }
        $(".app-container").hide();
        $("#app-staff-info-container").show();
    };
    // Nhấn nút quay lại màn hình list từ màn hình info
    $("#app-back-to-staff-list").click(function () {
        $(".app-container").hide();
        $("#app-staff-list-container").show();
    });
    // Nhấn nút chỉnh sửa hồ sơ nhân viên
    $("#app-edit-staff").click(function () {
        window.location.href = "edit-staff.jsp?staffId=" + encodeURIComponent(window.STAFF_INFO_SCREEN.staffId);
    });
    // Nhấn nút xóa hồ sơ nhân viên
    $("#app-delete-staff").click(function () {
        DonexApp.Control.showRedYesNoDialog("Bạn có chắc muốn xóa thông tin nhân viên này?", function () {
            DonexApp.Control.showLoading();
            DonexApp.Api.deleteStaff(window.STAFF_INFO_SCREEN.staffId,
                function (data) {
                    if (data.code == DonexApp.Api.RESPONSE_CODE.SUCCESS) {
                        DonexApp.Control.showOkDialog("Thông tin của nhân viên này đã bị xóa!", function () {
                            window.location = "staff.jsp";
                        });
                    } else {
                        DonexApp.Control.showRedOkDialog("Có lỗi xảy ra, hiện chưa xóa được thông tin nhân viên này! Vui lòng thử lại sau.");
                    }
                },
                function () {
                    DonexApp.Control.showRedOkDialog("Có lỗi xảy ra, hiện chưa xóa được thông tin nhân viên này! Vui lòng thử lại sau.");
                },
                function () {
                    DonexApp.Control.hideLoading();
                });
        });
    });

    /******************************** MÀN HÌNH LIST ********************************/
    var displayStaffList = function (staffList) {
        var $table = $("table.app-fragment").clone();
        $table.attr("id", "app-staff-list-table").removeClass("app-fragment");
        $table[0].listData = staffList;
        $table[0].showTableData = function (fromItemIndex, toItemIndex) {
            // Đổ dữ liệu vào bảng
            var $table = $(this);
            var $tbody = $table.find("tbody").empty();
            var $thead = $table.find("thead").empty();

            var listData = $table[0].listData;

            $thead.append("<tr><th style='width: 0.8cm;'>#</th><th style='width: 1cm;'>&nbsp;</th><th>Tên</th><th>Mã nhân viên</th><th>Ngày sinh</th><th>Giới tính</th><th style='width: 0.8cm;'>&nbsp;</th></tr>");

            for (var index = fromItemIndex; index <= toItemIndex; index++) {
                var data = listData[index - 1];
                var $row = $("<tr></tr>");
                var $avatarColumn = $("<td></td>");
                var $avatarImage = $("<img style='width: 1.5cm; height: 1.5cm; border-radius: 0.3cm;' />");
                $avatarColumn.append($avatarImage);
                if (data.avatarId != null) {
                    $avatarImage.attr("src", DonexApp.Api.Constants.API_IMAGE_URL + data.avatarId);
                } else {
                    $avatarImage.attr("src", "assets/img/app/missing-avatar.jpg");
                }
                var $nameColumn = $("<td></td>").text(data.name == null ? "" : data.name);
                var $staffIdCulumn = $("<td></td>").text(data.staffId == null ? "" : data.staffId);
                var $dateOfBirthColumn = $("<td></td>");
                if (data.dateOfBirth != null) {
                    $dateOfBirthColumn.text(DonexApp.Utils.timestampToShortDateString(data.dateOfBirth));
                }
                var $sexColumn = $("<td></td>").text(data.sex == null ? "" : data.sex); // TODO incomplete API
                $row.append("<td>" + index + "</td>")
                    .append($avatarColumn)
                    .append($nameColumn)
                    .append($staffIdCulumn)
                    .append($dateOfBirthColumn)
                    .append($sexColumn);
                $row.append($("<td></td>").append(
                    $("<button class='btn app-staff-info-button'><i class='glyphicon glyphicon-user'>&nbsp;</i>Xem hồ sơ</button>")
                        .attr("staffId", data.staffId)
                        .unbind().click(showStaffInfo))
                );
                $tbody.append($row);
            }
        };

        // Hiển thị bảng và nút phân trang
        var $container = $("#app-staff-list-container").empty();
        var $pagination = DonexApp.Utils.createPagination($table, function (fromIndex, toIndex) {
            $table[0].showTableData(fromIndex, toIndex);
        });
        $container.append($pagination);
        $container.append($table);
        $($pagination.find("[app-index=1]")).click();
    };

    // Tải thông tin tất cả level của staff về
    var downloadLevelInformation = function () {
        DonexApp.Api.getAllLevel(
            function (response) {
                if (response.code == DonexApp.Api.RESPONSE_CODE.SUCCESS) {
                    window.allLevel = response.data;
                    if (window.allLevel == null) {
                        window.allLevel = [];
                    }

                    window.levelMap = {};
                    $.each(window.allLevel, function (index, value) {
                        window.levelMap[value.level] = value;
                    });

                    // --- Next task
                    displayStaffList(window.allStaff);
                } else {
                    DonexApp.Control.showRedOkDialog("Có lỗi xảy ra. Vui lòng thử lại sau.", function () {
                        window.location = "index.jsp";
                    });
                }
            },
            function () {
                DonexApp.Control.showRedOkDialog("Có lỗi xảy ra với đường truyền internet hoặc server.\nVui lòng thử lại sau.", function () {
                    window.location.reload();
                });
            },
            function () {
                DonexApp.Control.hideLoading();
            }
        );
    };
    // Tải thông tin tất cả staff về
    DonexApp.Control.showLoading();
    DonexApp.Api.getAllVisibleStaff(
        function (response) {
            if (response.code == DonexApp.Api.RESPONSE_CODE.SUCCESS) {
                var staffList = response.data;
                if (staffList == null) {
                    staffList = [];
                }
                window.allStaff = staffList;

                // Lưu dữ liệu list staff vào màn hình này
                window.staffMap = {};
                $(staffList).each(function (index, value) {
                    if (value.staffId != null) {
                        window.staffMap[value.staffId] = value;
                    }
                });

                // --- Next task
                downloadLevelInformation();
            } else {
                DonexApp.Control.hideLoading();
                DonexApp.Control.showRedOkDialog("Có lỗi xảy ra. Vui lòng thử lại sau.", function () {
                    window.location = "index.jsp";
                });
            }
        },
        function () {
            DonexApp.Control.hideLoading();
            DonexApp.Control.showRedOkDialog("Có lỗi xảy ra. Vui lòng thử lại sau.", function () {
                window.location = "index.jsp";
            });
        },
        function () {

        },
        0,
        999 // TODO change page and size
    );
});