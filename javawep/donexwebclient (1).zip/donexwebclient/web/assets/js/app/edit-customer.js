$(document).ready(function () {
    /** Chỉnh lại một số input **/

    var removeTag = function () {
        $(this).parent().remove();
    };

    var setupStaffIdInput = function () {
        var $inputCustomerStaffId = $("#input-customer-staff-id");
        $inputCustomerStaffId.empty();

        $inputCustomerStaffId.append("<option value='' style='font-style: italic; color: lightgray;'>(Bỏ trống)</option>");

        var currentLoginStaff = DonexApp.Utils.getCurrentLoginStaff();
        if (currentLoginStaff.level == DonexApp.Constants.NVKD_LEVEL_NUMBER) {
            $inputCustomerStaffId.append($("<option></option>").val(currentLoginStaff.staffId).text(currentLoginStaff.staffId + " (" + currentLoginStaff.name + ")"));
        }

        $.each(window.allStaff, function (index, staffObject) {
            if (staffObject.level == DonexApp.Constants.NVKD_LEVEL_NUMBER) {
                var $option = $("<option></option>");
                $option.attr("value", staffObject.staffId).text(staffObject.staffId + " (" + staffObject.name + ")");
                $inputCustomerStaffId.append($option);
            }
        });

        // Ô nhập để tìm kiếm nhanh
        var $helper = $("#input-superior-staff-id-helper");
        $helper.unbind("change").on('change', function () {
            var terms = $helper.val().split(/\s+/);

            $inputCustomerStaffId.find("option").each(function (index, inputOption) {
                var $inputOption = $(inputOption);
                if ($inputOption.val() != "") {
                    var searchText = $inputOption.text();
                    var matched = true;
                    for (var termIndex = 0; termIndex < terms.length; termIndex++) {
                        if (DonexApp.Utils.removeVietnameseToneMark(searchText.toLowerCase())
                                .indexOf(DonexApp.Utils.removeVietnameseToneMark(terms[termIndex])) <= -1) {
                            matched = false;
                            break;
                        }
                    }
                    if (matched) {
                        $(inputOption).show();
                    } else {
                        $(inputOption).hide();
                    }
                }
            });
        });

        // Nhấn nút thêm group tag
        $("#input-customer-add-group-tag-button").unbind().click(function () {
            var $inputGroupTag = $("#input-customer-group-tag");
            var inputTagString = $.trim($inputGroupTag.val());
            if (inputTagString != "") {
                inputTagString = DonexApp.Utils.upperCaseBeginning(inputTagString);
                $inputGroupTag.val(inputTagString);

                var isExisted = false;
                $("#list-customer-group-tag").find(".app-tag").each(function (index, tagObject) {
                    if ($(tagObject).attr("value") == inputTagString) {
                        isExisted = true;
                        return false;
                    }
                });

                if (isExisted) {
                    DonexApp.Control.showOkDialog("Đã có group này rồi!", function () {
                        $inputGroupTag.select();
                    });
                } else {
                    var $tag = DonexApp.Control.makeTag(inputTagString, removeTag);
                    $tag.attr("value", inputTagString);
                    $("#list-customer-group-tag").append($tag);
                }
            }
        });

        pullCustomerDataToForm();
    };

    /** **/
    // Nhấn nút cập nhật ảnh minh họa
    $("#input-submit-edit-image").click(function () {
        var inputFile = $("#input-customer-image")[0];

        if (inputFile.value == "") {
            DonexApp.Control.showOkDialog("Bạn phải chọn file ảnh để cập nhật!");
        } else if (inputFile.files[0].size >= DonexApp.Config.MAX_FILE_SIZE) {
            DonexApp.Control.showOkDialog("Bạn phải chọn file ảnh có kích thước nhỏ hơn " + (DonexApp.Config.MAX_FILE_SIZE / 1024) + "KB để cập nhật!");
        } else {
            DonexApp.Control.showLoading();
            DonexApp.Api.uploadCustomerAvatar(customer.customerId, inputFile,
                function (response) {
                    if (response.code == DonexApp.Api.RESPONSE_CODE.SUCCESS) {
                        DonexApp.Control.showOkDialog("Cập nhật thành công ảnh minh họa!");
                        window.customer.imageId = response.data.imageId;
                        if (window.customer.imageId !== undefined && window.customer.imageId != null && window.customer.imageId != "") {
                            $("#app-customer-image").attr("src", DonexApp.Api.Constants.API_IMAGE_URL + window.customer.imageId);
                        }
                    } else {
                        DonexApp.Control.showRedOkDialog("Vui lòng chọn 1 bức ảnh đúng như yêu cầu!");
                    }
                },
                function () {
                    DonexApp.Control.showRedOkDialog("Có lỗi xảy ra! Ảnh chưa được cập nhật. Vui lòng thử lại sau.");
                },
                function () {
                    DonexApp.Control.hideLoading();
                }
            );
        }
        return false;
    });

    // Nhấn nút cập nhật thông tin khách hàng
    $("#input-submit-edit").click(function () {

        // email
        var $inputEmail = $("#input-customer-email");
        var inputStaffEmailVal = $.trim($inputEmail.val());
        if (inputStaffEmailVal != "" && !DonexApp.Constants.EMAIL_REGEX.test(inputStaffEmailVal)) {
            DonexApp.Control.showRedOkDialog("Vui lòng nhập đúng định dạng địa chỉ email", function () {
                $inputEmail.focus();
            });
            return false;
        }

        var newCustomer = {};

        newCustomer.name = $("#input-customer-name").val();
        newCustomer.vicegerent = $("#input-customer-vicegerent").val();
        newCustomer.vicegerentInfo = $("#input-customer-vicegerent-info").val();
        newCustomer.staffId = $("#input-customer-staff-id").val();
        newCustomer.address = $("#input-customer-address").val();
        newCustomer.taxCode = $("#input-customer-tax-code").val();
        newCustomer.mobile = $("#input-customer-mobile").val();
        newCustomer.phone = $("#input-customer-phone").val();
        newCustomer.email = $("#input-customer-bank-account-number").val();

        newCustomer.groupTag = [];
        $("#list-customer-group-tag").find(".app-tag").each(function (index, appTag) {
            newCustomer.groupTag.push($(appTag).attr("value"));
        });

        $.each(newCustomer, function (key, value) {
            if (key != "groupTag" && value != null) {
                if (($.trim(value).length == 0 && (customer[key] == null || customer[key] === undefined)) || $.trim(value) == customer[key]) {
                    newCustomer[key] = null;
                } else {
                    newCustomer[key] = $.trim(value);
                }
            }
        });
        // Không sửa Id
        newCustomer.customerId = customer.customerId;

        DonexApp.Control.showLoading();
        DonexApp.Api.updateCustomer(newCustomer,
            function (data) {
                if (data.code == DonexApp.Api.RESPONSE_CODE.SUCCESS) {
                    DonexApp.Control.showOkDialog("Đã cập nhật!", function () {
                        location.reload();
                    });
                } else if (data.code == DonexApp.Api.RESPONSE_CODE.NOT_EXISTED) {
                    DonexApp.Control.showRedOkDialog("Không tồn tại khách hàng có mã [" + newCustomer.customerId + "] trong cơ sở dữ liệu. Mời bạn quay về chọn lại.", function () {
                        location.reload();
                    });
                }
            },
            function (data) {
                $("#app-alert-box").text("Có lỗi xảy ra. Vui lòng thử lại sau.").show();
            },
            function () {
                DonexApp.Control.hideLoading();
            }
        );

        return false;
    });

    /********************************  ********************************/

    var showError = function (message) {
        $("#app-alert-box").text(message);
        $("#app-alert-box-container").show();
    };
    var hideError = function () {
        $("#app-alert-box-container").hide();
    };
    var pullCustomerDataToForm = function () {
        $("#input-customer-id").val(customer.customerId == null ? "" : customer.customerId);
        $("#input-customer-name").val(customer.name == null ? "" : customer.name);
        $("#input-customer-vicegerent").val(customer.vicegerent == null ? "" : customer.vicegerent);
        $("#input-customer-vicegerent-info").val(customer.vicegerentInfo == null ? "" : customer.vicegerentInfo);
        $("#input-customer-staff-id").val(customer.staffId == null ? "" : customer.staffId);
        $("#input-customer-address").val(customer.address == null ? "" : customer.address);
        $("#input-customer-tax-code").val(customer.taxCode == null ? "" : customer.taxCode);
        $("#input-customer-mobile").val(customer.mobile == null ? "" : customer.mobile);
        $("#input-customer-phone").val(customer.phone == null ? "" : customer.phone);
        $("#input-customer-bank-account-number").val(customer.bankAccountNumber == null ? "" : customer.bankAccountNumber);

        if ($.isArray(customer.groupTag)) {
            $("#list-customer-group-tag").empty();
            $.each(customer.groupTag, function (index, tagString) {
                var $tag = DonexApp.Control.makeTag(tagString, removeTag);
                $tag.attr("value", tagString);
                $("#list-customer-group-tag").append($tag);
            });
        }

        if (customer.imageId !== undefined && customer.imageId != null && customer.imageId != "") {
            $("#app-customer-image").attr("src", DonexApp.Api.Constants.API_IMAGE_URL + customer.imageId);
        }
    };

    /** Tải thông tin cần thiết về **/
    var downloadStaffInfo = function () {
        DonexApp.Api.getAllVisibleStaff(
            function (response) {
                if (response.code == DonexApp.Api.RESPONSE_CODE.SUCCESS) {
                    window.allStaff = response.data;
                    if (window.allStaff == null) {
                        window.allStaff = [];
                    }
                    setupStaffIdInput();
                } else {
                    DonexApp.Control.showRedOkDialog("Có lỗi xảy ra. Vui lòng thử lại sau.", function () {
                        window.location = "customer.jsp";
                    });
                }
            },
            function () {
                DonexApp.Control.showRedOkDialog("Có lỗi xảy ra. Vui lòng thử lại sau.", function () {
                    window.location = "customer.jsp";
                });
            },
            function () {
                DonexApp.Control.hideLoading();
            }
        );
    };

    // Tải thông tin sản phẩm về
    window.parameters = DonexApp.Utils.getUrlParameters();
    var customerId = window.parameters["customerId"];
    if (customerId !== undefined && customerId.length > 0) {
        DonexApp.Control.showLoading();
        hideError();
        DonexApp.Api.getCustomer(customerId,
            function (response) {
                if (response.code == DonexApp.Api.RESPONSE_CODE.SUCCESS) {
                    window.customer = response.data;
                    downloadStaffInfo();
                } else if (response.code == DonexApp.Api.RESPONSE_CODE.NOT_EXISTED) {
                    DonexApp.Control.hideLoading();
                    DonexApp.Control.showRedOkDialog("Không tìm thấy khách hàng này trong cơ sở dữ liệu (có thể là vừa mới bị xóa?)", function () {
                        window.location = "customer.jsp";
                    });
                } else {
                    DonexApp.Control.hideLoading();
                    DonexApp.Control.showRedOkDialog("Có lỗi xảy ra. Vui lòng thử lại sau.", function () {
                        window.location = "customer.jsp";
                    });
                }
            },
            function () {
                DonexApp.Control.hideLoading();
                DonexApp.Control.showRedOkDialog("Có lỗi xảy ra. Vui lòng thử lại sau.", function () {
                    window.location = "customer.jsp";
                });
            },
            function () {
            });
    } else {
        window.location = "customer.jsp";
    }


    /********************************  ********************************/

});
