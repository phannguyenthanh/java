$(document).ready(function () {
    /** Chỉnh lại một chút các input **/
    $(".app-input-date").datepicker({
        yearRange: "-90:+0",
        changeYear: true,
        dateFormat: 'dd/mm/yy',
        defaultDate: '01/01/1990'
    });
    var setupLevelInput = function () {
        var $inputLevel = $("#input-level");
        $inputLevel.empty();
        $inputLevel.append("<option value='' style='font-style: italic; color: lightgray;'>(Bỏ trống)</option>");
        $.each(window.allLevel, function (index, levelObject) {
            var $option = $("<option></option>");
            $option.attr("value", levelObject.level).text(levelObject.levelName);
            $inputLevel.append($option);
        });
    };
    var setupSuperiorStaffInput = function () {
        var $inputSuperiorStaff = $("#input-superior-staff-id");
        $inputSuperiorStaff.empty();

        $inputSuperiorStaff.append("<option value='' style='font-style: italic; color: lightgray;'>(Bỏ trống)</option>");

        $.each(window.allStaff, function (index, staffObject) {
            var $option = $("<option></option>");
            $option.attr("value", staffObject.staffId).text(staffObject.staffId + " (" + staffObject.name + ")");
            $inputSuperiorStaff.append($option);
        });

        // Ô nhập để tìm kiếm nhanh
        var $helper = $("#input-superior-staff-id-helper");
        $helper.unbind("change").on('change', function () {
            var terms = $helper.val().split(/\s+/);

            // Xem có match với user nào mình đang quản lý không
            $inputSuperiorStaff.find("option").each(function (index, inputOption) {
                var $inputOption = $(inputOption);
                if ($inputOption.val() != "") {
                    var searchText = $inputOption.text();
                    var matched = true;
                    for (var termIndex = 0; termIndex < terms.length; termIndex++) {
                        if (DonexApp.Utils.removeVietnameseToneMark(searchText.toLowerCase())
                                .indexOf(DonexApp.Utils.removeVietnameseToneMark(terms[termIndex])) <= -1) {
                            matched = false;
                            break;
                        }
                    }
                    if (matched) {
                        $(inputOption).show();
                    } else {
                        $(inputOption).hide();
                    }
                }
            });
        });
    };

    /** Validate dữ liệu nhập **/
    var validateInput = function () {
        // staff id
        var $inputStaffId = $("#input-staff-id");
        if ($.trim($inputStaffId.val()) == "") {
            DonexApp.Control.showRedOkDialog("Mã nhân viên không được bỏ trống", function () {
                $inputStaffId.focus();
            });
            return false;
        }
        // email
        var $inputStaffEmail = $("#input-email");
        var inputStaffEmailVal = $.trim($inputStaffEmail.val());
        if (inputStaffEmailVal != "" && !DonexApp.Constants.EMAIL_REGEX.test(inputStaffEmailVal)) {
            DonexApp.Control.showRedOkDialog("Vui lòng nhập đúng định dạng địa chỉ email", function () {
                $inputStaffEmail.focus();
            });
            return false;
        }
        // avatar
        var $inputAvatar = $("#input-staff-avatar");
        if ($inputAvatar[0].files.length > 0 && $inputAvatar[0].files[0].size >= DonexApp.Config.MAX_FILE_SIZE) {
            DonexApp.Control.showRedOkDialog("File avatar không được vượt quá 1MB", function () {
                $("#input-staff-avatar").focus();
            });
            return false;
        }
    };

    /** Tải dữ liệu lên server **/
    // Bắt đầu tải lên thông tin
    var uploadAvatar = function (staffId, inputFile) {
        DonexApp.Api.uploadStaffAvatar(staffId, inputFile,
            function (data) {
                if (data.code == DonexApp.Api.RESPONSE_CODE.SUCCESS) {
                    DonexApp.Control.showOkDialog("Đã thêm nhân viên!", function () {
                        window.location.reload();
                    });
                } else {
                    DonexApp.Control.showOkDialog("Đã thêm nhân viên! Tuy nhiên ảnh đại diện chưa được cập nhật.", function () {
                        window.location.reload();
                    });
                }
            },
            function () {
                DonexApp.Control.showOkDialog("Đã thêm nhân viên! Tuy nhiên ảnh đại diện chưa được cập nhật.", function () {
                    window.location.reload();
                });
            },
            function () {
                DonexApp.Control.hideLoading();
            }
        );
    };
    $("#input-submit-add").click(function () {
        try {

            if (!validateInput()) {
                return false;
            }

            DonexApp.Control.showLoading();
            $("#app-alert-box").hide();

            var staff = {};

            staff.staffId = $("#input-staff-id").val();
            staff.superiorStaffId = $("#input-superior-staff-id").val();
            staff.name = $("#input-staff-name").val();
            staff.dateOfBirth = getDateFromFormat($("#input-date-of-birth").val(), "dd/MM/yyyy");
            staff.level = $("#input-level").val();
            staff.mobile = $("#input-mobile").val();
            staff.alternativeMobile = $("#input-alternative-mobile").val();
            staff.email = $("#input-email").val();
            staff.cmnd = $("#input-cmnd").val();
            staff.permanentAddress = $("#input-permanent-address").val();
            staff.livingAddress = $("#input-living-address").val();
            staff.startWorkingDate = getDateFromFormat($("#input-start-working-date").val(), "dd/MM/yyyy");
            staff.endWorkingDate = getDateFromFormat($("#input-end-working-date").val(), "dd/MM/yyyy");
            staff.employmentStatus = $("#input-employment-status").val();

            if (staff.dateOfBirth == 0) {
                staff.dateOfBirth = null;
            }
            if (staff.startWorkingDate == 0) {
                staff.startWorkingDate = null;
            }
            if (staff.endWorkingDate == 0) {
                staff.endWorkingDate = null;
            }
            $.each(staff, function (key, value) {
                if (value != null) {
                    if ($.trim(value).length == 0) {
                        staff[key] = null;
                    } else {
                        staff[key] = $.trim(value);
                    }
                }
            });
            if (staff.superiorStaffId != null)
                var superiorStaffIdParts = staff.superiorStaffId.split(/\s+\(/);
            if ($.isArray(superiorStaffIdParts) && superiorStaffIdParts.length >= 1) {
                staff.superiorStaffId = superiorStaffIdParts[0];
            } else {
                staff.superiorStaffId = null;
            }

            DonexApp.Api.addStaff(staff,
                function (data, textStatus, jqXHR) {
                    if (data.code == DonexApp.Api.RESPONSE_CODE.SUCCESS) {
                        var inputFile = $("#input-staff-avatar");
                        if (inputFile.value != "") {
                            uploadAvatar(staff.staffId, inputFile[0]);
                        } else {
                            DonexApp.Control.showOkDialog("Đã thêm nhân viên!", function () {
                                window.location.reload();
                            });
                        }
                    } else if (data.code == DonexApp.Api.RESPONSE_CODE.EXISTED) {
                        DonexApp.Control.hideLoading();
                        DonexApp.Control.showRedOkDialog("Đã tồn tại nhân viên với mã " + staff.staffId + " trong cơ sở dữ liệu. Mời bạn sử dụng mã nhân viên khác.", function () {
                            $("#app-staff-id").focus();
                        });
                    }
                },
                function () {
                    DonexApp.Control.hideLoading();
                    DonexApp.Control.showRedOkDialog("Có lỗi xảy ra. Vui lòng thử lại sau.", function () {
                        window.location = "index.jsp";
                    });
                },
                function () {
                });
        } catch (ex) {
            console.log(ex);
        }
        return false;
    });

    /** Tải dữ liệu cần thiết từ trên server **/
    // Tải thông tin tất cả staff về
    DonexApp.Control.showLoading();
    DonexApp.Api.getAllVisibleStaff(
        function (response) {
            if (response.code == DonexApp.Api.RESPONSE_CODE.SUCCESS) {
                window.allStaff = response.data;
                if (window.allStaff == null) {
                    window.allStaff = [];
                }
                setupSuperiorStaffInput();
                downloadLevelInformation();
            } else {
                DonexApp.Control.hideLoading();
                DonexApp.Control.showRedOkDialog("Có lỗi xảy ra. Vui lòng thử lại sau.", function () {
                    window.location = "index.jsp";
                });
            }
        },
        function () {
            DonexApp.Control.hideLoading();
            DonexApp.Control.showRedOkDialog("Có lỗi xảy ra với đường truyền internet hoặc server.\nVui lòng thử lại sau.", function () {
                window.location.reload();
            });
        },
        function () {
        }
    );
    // Tải thông tin tất cả level của staff về
    var downloadLevelInformation = function () {
        DonexApp.Api.getAllLevel(
            function (response) {
                if (response.code == DonexApp.Api.RESPONSE_CODE.SUCCESS) {
                    window.allLevel = response.data;
                    if (window.allLevel == null) {
                        window.allLevel = [];
                    }

                    window.levelMap = {};
                    $.each(window.allLevel, function (index, value) {
                        window.levelMap[value.level] = value;
                    });

                    setupLevelInput();
                } else {
                    DonexApp.Control.showRedOkDialog("Có lỗi xảy ra. Vui lòng thử lại sau.", function () {
                        window.location = "index.jsp";
                    });
                }
            },
            function () {
                DonexApp.Control.showRedOkDialog("Có lỗi xảy ra với đường truyền internet hoặc server.\nVui lòng thử lại sau.", function () {
                    window.location.reload();
                });
            },
            function () {
                DonexApp.Control.hideLoading();
            }
        );
    }
});