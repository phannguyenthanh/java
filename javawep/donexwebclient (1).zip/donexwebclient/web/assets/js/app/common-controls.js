DonexApp.Control = {};
DonexApp.Control.showLoading = function () {
    $("#app-loading-screen").show();
};
DonexApp.Control.hideLoading = function () {
    $("#app-loading-screen").hide();
};
DonexApp.Control.showOkDialog = function (message, clickCallback) {
    var $dialog = $("#app-ok-dialog");
    $($dialog.find(".app-dialog-message")).text(message);
    $($dialog.find(".app-dialog-ok-button")).click(function () {
        $dialog.hide();
        if ($.isFunction(clickCallback)) {
            clickCallback();
        }
        return false;
    });
    $dialog.show();
};
DonexApp.Control.showRedOkDialog = function (message, clickCallback) {
    var $dialog = $("#app-red-ok-dialog");
    $($dialog.find(".app-dialog-message")).text(message);
    $($dialog.find(".app-dialog-ok-button")).unbind().click(function () {
        $dialog.hide();
        if ($.isFunction(clickCallback)) {
            clickCallback();
        }
        return false;
    });
    $dialog.show();
};
DonexApp.Control.showRedYesNoDialog = function (message, clickCallback) {
    var $dialog = $("#app-red-yes-no-dialog");
    $($dialog.find(".app-dialog-message")).text(message);
    $($dialog.find(".app-dialog-yes-button")).unbind().click(function () {
        $dialog.hide();
        if ($.isFunction(clickCallback)) {
            clickCallback();
        }
        return false;
    });
    $($dialog.find(".app-dialog-no-button")).unbind().click(function () {
        $dialog.hide();
        return false;
    });
    $dialog.show();
};
DonexApp.Control.makeTag = function (tagName, xClickCallback) {
    var tag = $(".app-fragment").first().clone();
    tag.removeClass("app-fragment").addClass("app-tag");
    tag.find(".app-tag-name").text(tagName);
    tag.find(".app-tag-x-button").unbind().click(xClickCallback);
    tag.css("display", "inline-block");
    return tag;
};