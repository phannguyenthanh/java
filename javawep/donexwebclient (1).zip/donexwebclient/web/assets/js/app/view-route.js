window.ReadyStatus = {};
window.ReadyStatus.document = false;
window.ReadyStatus.googleMap = false;

function onComponentReady(which) {
    if (which === undefined || which == null) return;
    window.ReadyStatus[which] = true;
    if (window.ReadyStatus.document && window.ReadyStatus.googleMap) {
        // Tất cả đã sẵn sàng làm việc
        downloadAllInferiorPos();
    }
}

function downloadAllInferiorPos () {

    // TODO call api
    window.DOWNLOADED_INFERIOR = [];
    DOWNLOADED_INFERIOR.push({
        staffId: "ST001",
        lat: 21.02875,
        lng: 105.8501
    });
    DOWNLOADED_INFERIOR.push({
        staffId: "ST002",
        lat: 21.02855,
        lng: 105.8521
    });
    DOWNLOADED_INFERIOR.push({
        staffId: "ST003",
        lat: 21.02865,
        lng: 105.8531
    });
    // End calling api

    if (DonexApp.Utils.isUnset(window.INFERIORS)) {
        window.INFERIORS = {};
    }

    $.each(window.DOWNLOADED_INFERIOR, function (index, staffPos){
        if (Utils.isSet(staffPos.staffId)) {
            if (Utils.isSet(INFERIORS[staffPos.staffId])) {
                INFERIORS[staffPos.staffId].lat = staffPos.latitude;
                INFERIORS[staffPos.staffId].lng = staffPos.longitude;
                INFERIORS[staffPos.staffId].marker.setPosition(new google.maps.LatLng(staffPos.latitude, staffPos.longitude));
            }
        } else {
            var marker = new google.maps.Marker({
                position: {lat: staffPos.latitude, lng: staffPos.longitude},
                map: window.GoogleMap,
                icon: 'assets/img/app/test-marker.png'
            });
            staffPos.marker = marker;
            marker.staff = staffPos;
            marker.addListener('click', function () {
                alert("Staff Id = " + this.staff.staffId);
            });
        }
    });
    // TODO remove not listed inferior
    // . End remove not listed inferior
}

function updateMarkerPosition() {

}

// Document ready
$(document).ready(function () {
    onComponentReady("document");
});
// Google init map
function initMap() {
    window.GoogleMap = new google.maps.Map(document.getElementById('map'), {
        center: {lat: 21.0287542, lng: 105.8501718},
        zoom: 16
    });
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(function (position) {
            var pos = {
                lat: position.coords.latitude,
                lng: position.coords.longitude
            };

            GoogleMap.setCenter(pos);
        }, function () {
            console.log("[E] Trình duyệt không hỗ trợ lấy vị trí");
        });
    }
    onComponentReady("googleMap");
}

