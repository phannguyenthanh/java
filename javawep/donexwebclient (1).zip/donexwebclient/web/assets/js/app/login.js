$(document).ready(function () {
    var showAlertBox = function (message) {
        var $alertBox = $("#app-alert-box");
        $alertBox.text(message);
        $alertBox.show();
    };
    $("#app-login-button").unbind().click(function () {
        DonexApp.Control.showLoading();
        DonexApp.Api.login($("#app-staff-id").val(), $("#app-staff-password").val(),
            function (response, status, xhr) {
                if (response.code == DonexApp.Api.RESPONSE_CODE.SUCCESS) {
                    window.location = "index.jsp";
                } else if (response.code == DonexApp.Api.RESPONSE_CODE.NOT_EXISTED_STAFF) {
                    showAlertBox("Không tìm thấy tài khoản tương ứng.\nVui lòng nhập lại thông tin.")
                } else if (response.code == DonexApp.Api.RESPONSE_CODE.WRONG_PASSWORD) {
                    showAlertBox("Mật khẩu không đúng.\nVui lòng nhập lại thông tin.")
                } else if (response.code == DonexApp.Api.RESPONSE_CODE.UNKNOWN_ERROR) {
                    showAlertBox("Server gặp sự cố. Vui lòng thử lại sau.")
                } else {
                    showAlertBox("Có lỗi xảy ra. Vui lòng thử lại sau.")
                }
            },
            function (response, status, xhr) {
                showAlertBox("Lỗi: " + status.statusText);
            },
            function (response, status, xhr) {
                DonexApp.Control.hideLoading();
            }
        );
    });
});