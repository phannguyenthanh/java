$(document).ready(function () {

    var removeTag = function () {
        $(this).parent().remove();
    };

    // Nhấn nút cập nhật ảnh minh họa
    $("#input-submit-edit-image").click(function () {
        var inputFile = $("#input-goods-image")[0];

        if (inputFile.value == "") {
            DonexApp.Control.showOkDialog("Bạn phải chọn file ảnh để cập nhật!");
        } else if (inputFile.files[0].size >= DonexApp.Config.MAX_FILE_SIZE) {
            DonexApp.Control.showOkDialog("Bạn phải chọn file ảnh có kích thước nhỏ hơn " + (DonexApp.Config.MAX_FILE_SIZE / 1024) + "KB để cập nhật!");
        } else {
            DonexApp.Control.showLoading();
            DonexApp.Api.uploadGoodsAvatar(goods.goodsId, inputFile,
                function (response) {
                    if (response.code == DonexApp.Api.RESPONSE_CODE.SUCCESS) {
                        DonexApp.Control.showOkDialog("Cập nhật thành công ảnh minh họa!");
                        window.goods.imageId = response.data.imageId;
                        if (window.goods.imageId !== undefined && window.goods.imageId != null && window.goods.imageId != "") {
                            $("#app-goods-image").attr("src", DonexApp.Api.Constants.API_IMAGE_URL + window.goods.imageId);
                        }
                    } else {
                        DonexApp.Control.showRedOkDialog("Vui lòng chọn 1 bức ảnh đúng như yêu cầu!");
                    }
                },
                function () {
                    DonexApp.Control.showRedOkDialog("Có lỗi xảy ra! Ảnh minh họa chưa được cập nhật. Vui lòng thử lại sau.");
                },
                function () {
                    DonexApp.Control.hideLoading();
                }
            );
        }
        return false;
    });

    // Nhấn nút cập nhật thông tin sản phẩm
    $("#input-submit-edit").click(function () {

        var newGoods = {};

        newGoods.name = $("#input-goods-name").val();
        newGoods.unit = $("#input-goods-unit").val();
        newGoods.price = $("#input-goods-price").val();
        newGoods.category = [];
        $(".app-goods-category").each(function (index, element) {
            var $element = $(element);
            if ($element.is(":checked")) {
                newGoods.category.push($element.attr("app-goods-category"));
            }
        });
        newGoods.color = $("#input-goods-color").val();
        newGoods.sizes = [];
        $(".app-goods-size:checked").each(function (index, input) {
            goods.sizes.push($(input).val());
        });

        $.each(newGoods, function (key, value) {
            if (key != "sizes" && key != "category" && value != null) {
                if (($.trim(value).length == 0 && (goods[key] == null || goods[key] === undefined)) || $.trim(value) == goods[key]) {
                    newGoods[key] = null;
                } else {
                    newGoods[key] = $.trim(value);
                }
            }
        });
        // Không sửa Id
        newGoods.goodsId = goods.goodsId;

        DonexApp.Control.showLoading();
        DonexApp.Api.updateGoods(newGoods,
            function (data) {
                if (data.code == DonexApp.Api.RESPONSE_CODE.SUCCESS) {
                    DonexApp.Control.showOkDialog("Đã cập nhật!", function () {
                        location.reload();
                    });
                } else if (data.code == DonexApp.Api.RESPONSE_CODE.NOT_EXISTED) {
                    DonexApp.Control.showRedOkDialog("Không tồn tại sản phẩm tên (" + goods.name + ") với mã " + goods.goodsId + " trong cơ sở dữ liệu. Mời bạn quay về chọn lại.", function () {
                        location.reload();
                    });
                }
            },
            function (data) {
                $("#app-alert-box").text("Có lỗi xảy ra. Vui lòng thử lại sau.").show();
            },
            function () {
                DonexApp.Control.hideLoading();
            }
        );

        return false;
    });

    /********************************  ********************************/

    var showError = function (message) {
        $("#app-alert-box").text(message);
        $("#app-alert-box-container").show();
    };
    var hideError = function () {
        $("#app-alert-box-container").hide();
    };
    var pullGoodsDataToForm = function () {
        $("#input-goods-id").val(goods.goodsId == null ? "" : goods.goodsId);
        $("#input-goods-name").val(goods.name == null ? "" : goods.name);
        $("#input-goods-unit").val(goods.unit == null ? "" : goods.unit);
        $("#input-goods-price").val(goods.price == null ? "" : goods.price);

        if ($.isArray(goods.category)) {
            $("#list-goods-group-tag").empty();
            $.each(goods.category, function (index, tagString) {
                var $tag = DonexApp.Control.makeTag(tagString, removeTag);
                $tag.attr("value", tagString);
                $("#list-goods-group-tag").append($tag);
            });
        }

        $("#input-goods-color").val(goods.color == null ? "" : goods.color);
        if (goods.sizes != null && goods.sizes !== undefined) {
            $(".app-goods-size").each(function (index, input) {
                var $input = $(input);
                $input.prop("checked", $.inArray($input.val(), goods.sizes) >= 0);
            });
        }

        if (goods.imageId !== undefined && goods.imageId != null && goods.imageId != "") {
            $("#app-goods-image").attr("src", DonexApp.Api.Constants.API_IMAGE_URL + goods.imageId);
        }
    };

    // Tải thông tin sản phẩm về
    window.parameters = DonexApp.Utils.getUrlParameters();
    var goodsId = window.parameters["goodsId"];
    if (goodsId !== undefined && goodsId.length > 0) {
        $("#app-edit-goods-input-form").hide();
        DonexApp.Control.showLoading();
        hideError();
        DonexApp.Api.getGoods(goodsId,
            function (response) {
                if (response.code == DonexApp.Api.RESPONSE_CODE.SUCCESS) {
                    window.goods = response.data;
                    pullGoodsDataToForm();
                    $("#app-goods-input-form").show();
                } else if (response.code == DonexApp.Api.RESPONSE_CODE.NOT_EXISTED) {
                    DonexApp.Control.showRedOkDialog("Không tìm thấy sản phẩm này (có thể là vừa mới bị xóa?)", function () {
                        window.location = "goods.jsp";
                    });
                } else {
                    showError("Có lỗi xảy ra.\nVui lòng thử lại sau.")
                }
            },
            function () {
                showError("Có lỗi xảy ra với đường truyền internet hoặc server.\nVui lòng thử lại sau.")
            },
            function () {
                DonexApp.Control.hideLoading();
            });
    } else {
        window.location = "goods.jsp";
    }

    /********************************  ********************************/

});
