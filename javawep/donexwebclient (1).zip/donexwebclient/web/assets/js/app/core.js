// SOME FUNCTIONS
function zeroPad(num, places) {
    var zero = places - num.toString().length + 1;
    return Array(+(zero > 0 && zero)).join("0") + num;
}
window.Utils = {};
window.Utils.isUnset = function (input) {
    return (input === undefined || input == null);
};
window.Utils.isSet = function (input) {
    return (input !== undefined && input != null);
};
// . SOME FUNCTIONS
DonexApp = {};
DonexApp.Constants = {};
DonexApp.Constants.EMAIL_REGEX = /^(([^<>()\[\]\.,;:\s@\"]+(\.[^<>()\[\]\.,;:\s@\"]+)*)|(\".+\"))@(([^<>()[\]\.,;:\s@\"]+\.)+[^<>()[\]\.,;:\s@\"]{2,})$/i;
DonexApp.Constants.w_VIETNAMESE_REGEX = /^[0-9a-zA-Z_ÀÁÂÃÈÉÊÌÍÒÓÔÕÙÚĂĐĨŨƠàáâãèéêìíòóôõùúăđĩũơƯĂẠẢẤẦẨẪẬẮẰẲẴẶẸẺẼỀỀỂưăạảấầẩẫậắằẳẵặẹẻẽềềểỄỆỈỊỌỎỐỒỔỖỘỚỜỞỠỢỤỦỨỪễệỉịọỏốồổỗộớờởỡợụủứừỬỮỰỲỴÝỶỸửữựỳỵỷỹ]/;
DonexApp.Constants.NVKD_LEVEL_NUMBER = 50;
DonexApp.Constants.ADMIN_LEVEL_NUMBER = 1;

DonexApp.Api = {};
DonexApp.Api.HEADERS = {};
DonexApp.Api.Constants = {};
DonexApp.Api.Constants.API_URL = "http://45.117.80.87:11881/api/v1/";
// DonexApp.Api.Constants.API_URL = "http://127.0.0.1:11881/api/v1/";
DonexApp.Api.Constants.API_IMAGE_URL = DonexApp.Api.Constants.API_URL + "file/image?imageId=";
// CONFIG
DonexApp.Config = {};
DonexApp.Config.pagination_row_number = 10;
DonexApp.Config.MAX_FILE_SIZE = 1023 * 1024;
// .CONFIG
// UTILS
DonexApp.Utils = {};
DonexApp.Utils.removeVietnameseToneMark = function (str) {
    str = str.toLowerCase();
    str = str.replace(/à|á|ạ|ả|ã|â|ầ|ấ|ậ|ẩ|ẫ|ă|ằ|ắ|ặ|ẳ|ẵ/g, "a");
    str = str.replace(/è|é|ẹ|ẻ|ẽ|ê|ề|ế|ệ|ể|ễ/g, "e");
    str = str.replace(/ì|í|ị|ỉ|ĩ/g, "i");
    str = str.replace(/ò|ó|ọ|ỏ|õ|ô|ồ|ố|ộ|ổ|ỗ|ơ|ờ|ớ|ợ|ở|ỡ/g, "o");
    str = str.replace(/ù|ú|ụ|ủ|ũ|ư|ừ|ứ|ự|ử|ữ/g, "u");
    str = str.replace(/ỳ|ý|ỵ|ỷ|ỹ/g, "y");
    str = str.replace(/đ/g, "d");
    return str;
};
DonexApp.Utils.timestampToLongDateString = function (timestamp) {
    var date = new Date(timestamp);
    return "Ngày " + date.getDate() + " tháng " + zeroPad(date.getMonth() + 1, 2) + " năm " + date.getFullYear();
};
DonexApp.Utils.timestampToShortDateString = function (timestamp) {
    var date = new Date(timestamp);
    return zeroPad(date.getDate(), 2) + "/" + zeroPad(date.getMonth() + 1, 2) + "/" + date.getFullYear();
};
DonexApp.Utils.makeBigSpinImg = function () {
    return $("<img src='assets/img/app/bigspin.gif' alt='xin chờ...'>");
};
DonexApp.Utils.createPagination = function ($table, onChangePage) {
    // Tạo nút phân trang dữ liệu
    var $pagination = $("<ul class='pagination'><li><a class='app-back-pagination' href='#'>«</a></li><li><a class='app-next-pagination' href='#'>»</a></li></ul>");
    $pagination[0].currentPageIndex = 1;
    $pagination[0].pageNumber = Math.floor($table[0].listData.length / DonexApp.Config.pagination_row_number);
    if ($pagination[0].pageNumber * DonexApp.Config.pagination_row_number < $table[0].listData.length) {
        $pagination[0].pageNumber++;
    }
    for (var page = 1; page <= $pagination[0].pageNumber; page++) {
        var fromIndex = ((page - 1) * DonexApp.Config.pagination_row_number + 1);
        var toIndex = (page * DonexApp.Config.pagination_row_number);
        if (toIndex > $table[0].listData.length) {
            toIndex = $table[0].listData.length;
        }
        $("<li><a class='app-index-pagination' app-index='" + page + "' app-from-index='" + fromIndex + "' app-to-index='" + toIndex + "' href='#'>" + page + "</a></li>")
            .insertBefore($pagination.find(".app-next-pagination").parent());
    }

    $pagination[0].changePage = function (index) {
        $pagination[0].currentPageIndex = index;
        var allLi = $pagination.find("li");
        $(allLi).removeClass("active");
        $(allLi[index]).addClass("active");
        if (index <= 1) {
            $($pagination.find(".app-back-pagination").parent()).addClass("disabled");
        } else {
            $($pagination.find(".app-back-pagination").parent()).removeClass("disabled");
        }
        if (index >= $pagination[0].pageNumber) {
            $($pagination.find(".app-next-pagination").parent()).addClass("disabled");
        } else {
            $($pagination.find(".app-next-pagination").parent()).removeClass("disabled");
        }
        if ($.isFunction(onChangePage)) {
            onChangePage(Number($($(allLi[index]).find("a")).attr("app-from-index")), Number($($(allLi[index]).find("a")).attr("app-to-index")));
        }
    };

    $($pagination.find(".app-back-pagination")).unbind().click(function () {
        if ($pagination[0].currentPageIndex > 1) {
            $pagination[0].changePage($pagination[0].currentPageIndex - 1);
        }
        return false;
    });
    $($pagination.find(".app-next-pagination")).unbind().click(function () {
        if ($pagination[0].currentPageIndex < $pagination[0].pageNumber) {
            $pagination[0].changePage($pagination[0].currentPageIndex + 1);
        }
        return false;
    });
    $($pagination.find(".app-index-pagination")).unbind().click(function () {
        $pagination[0].changePage(Number($(this).attr("app-index")));
        return false;
    });

    return $pagination;
};
DonexApp.Utils.getUrlParameters = function () {
    var vars = {};
    window.location.href.replace(/[?&]+([^=&]+)=([^&]*)/gi,
        function (m, key, value) {
            vars[decodeURIComponent(key)] = decodeURIComponent(value);
        });
    return vars;
};
DonexApp.Utils.getStaffListFromStaffTree = function (arrayOfTree) {
    var list = [];
    $.each(arrayOfTree, function (index, value) {
        list.push(value);
    });
    var index = 0;
    while (index < list.length) {
        var staff = list[index];
        $.each(staff.inferiorStaff, function (index, value) {
            list.push(value);
        });
        index++;
    }
    return list;
};
DonexApp.Utils.getCurrentLoginStaff = function () {
    if ($.cookie("UserInfo") !== undefined) {
        return JSON.parse($.cookie("UserInfo"));
    } else {
        return null;
    }
};
DonexApp.Utils.upperCaseBeginning = function (inputString) {
    var output = inputString[0].toUpperCase();
    for (var i = 1; i < inputString.length; i++) {
        if (inputString[i - 1].match(DonexApp.Constants.w_VIETNAMESE_REGEX) != null) {
            output += inputString[i];
        } else {
            output += inputString[i].toUpperCase();
        }
    }
    return output;
};
DonexApp.Utils.StaffSortingFunction = function (staff1, staff2) {
    if (Utils.isSet(staff1.level) && staff1.level != 0 && Utils.isSet(staff2.level) && staff2.level != 0) {
        return Number(staff1.level) - Number(staff2.level);
    } else if (Utils.isSet(staff1.level) && staff1.level != 0) {
        return -1;
    } else {
        return 1;
    }
};
// .UTILS

// API
DonexApp.Api.RESPONSE_CODE = {};
DonexApp.Api.RESPONSE_CODE.SUCCESS = 0;
DonexApp.Api.RESPONSE_CODE.UNKNOWN_ERROR = 1;
DonexApp.Api.RESPONSE_CODE.EXISTED = 2;
DonexApp.Api.RESPONSE_CODE.INVALID_ITEM = 3;
DonexApp.Api.RESPONSE_CODE.NOT_EXISTED = 4;
DonexApp.Api.RESPONSE_CODE.WRONG_PASSWORD = 5;
DonexApp.Api.RESPONSE_CODE.NOT_EXISTED_STAFF = 6;
DonexApp.Api.RESPONSE_CODE.INVALID_TOKEN = 7;
/*  ****************
 00:SUCCESS
 01:UNKNOWN_ERROR
 02:EXISTED
 03:INVAID_ITEM
 04:NOT_EXISTED
 05:WRONG_PASSWORD
 06:NOT_EXISTED_STAFF
 07:INVALID_TOKEN
 ****************
 */
DonexApp.Api.EMPLOYMENT_STATUS_MAP = {};
DonexApp.Api.EMPLOYMENT_STATUS_MAP[1] = "Đang làm";
DonexApp.Api.EMPLOYMENT_STATUS_MAP[2] = "Nghỉ tạm thời";
DonexApp.Api.EMPLOYMENT_STATUS_MAP[2] = "Đã nghỉ việc";

DonexApp.Api.uploadStaffAvatar = function (staffId, fileInput, doneCallback, failCallback, alwaysCallback) {
    var url = DonexApp.Api.Constants.API_URL + "file/avatar_staff";

    var formData = new FormData($("<form enctype='multipart/form-data'></form>")[0]);
    formData.append("staffId", staffId);
    formData.append("file", fileInput.files[0]);

    $.ajax({
        type: "POST",
        url: url,
        data: formData,
        dataType: 'json',
        cache: false,
        contentType: false,
        processData: false
    }).done(doneCallback).fail(failCallback).always(alwaysCallback);
};
/**
 * Lấy tất cả nhân viên mà mình được quyền quản lý
 * Nếu là admin thì được quyền quản lý tất cả nhân viên
 * Nếu không phải thì được quản lý tất cả nhân viên dưới quyền
 * *** Hiện tại admin có level cao nhất nên được phép quản lý tất cả
 * @param successCallback
 * @param errorCallback
 * @param alwaysCallback
 * @param page
 * @param size
 */
DonexApp.Api.getAllVisibleStaff = function (successCallback, errorCallback, alwaysCallback, page, size) {
    var currentUser = DonexApp.Utils.getCurrentLoginStaff();
    if (currentUser.level == DonexApp.Constants.ADMIN_LEVEL_NUMBER) {
        return DonexApp.Api.getAllStaff(function (response, error, xhr) {
            if ($.isFunction(successCallback)) {
                if (response.code == DonexApp.Api.RESPONSE_CODE.SUCCESS && $.isArray(response.data)) {
                    response.data.sort(DonexApp.Utils.StaffSortingFunction);
                }
                successCallback(response, error, xhr);
            }
        }, errorCallback, alwaysCallback, page, size);
    } else {
        return DonexApp.Api.getInferiorStaff(currentUser.staffId, function (response, error, xhr) {
            if ($.isFunction(successCallback)) {
                if (response.code == DonexApp.Api.RESPONSE_CODE.SUCCESS && $.isArray(response.data)) {
                    var currentStaff = $.extend({}, currentUser);
                    response.data.unshift(currentStaff);
                }
                successCallback(response, error, xhr);
            }
        }, errorCallback, alwaysCallback, page, size);
    }
};
DonexApp.Api.getAllStaff = function (successCallback, errorCallback, alwaysCallback, page, size) {
    var url = DonexApp.Api.Constants.API_URL + "staff/getall";
    if (page !== undefined && size !== undefined) {
        url += "?page=" + encodeURIComponent(page) + "&size=" + encodeURIComponent(size);
    }
    $.ajax({
        type: "GET",
        url: url,
        contentType: "application/json",
        dataType: "json"
    }).done(successCallback).fail(errorCallback).always(alwaysCallback);
};
DonexApp.Api.addStaff = function (data, doneCallback, failCallback, alwaysCallback) {
    var url = DonexApp.Api.Constants.API_URL + "staff/add";
    $.ajax({
        type: "POST",
        url: url,
        contentType: "application/json",
        dataType: "json",
        data: JSON.stringify(data)
    }).done(doneCallback).fail(failCallback).always(alwaysCallback);
};
DonexApp.Api.updateStaff = function (data, doneCallback, failCallback, alwaysCallback) {
    var url = DonexApp.Api.Constants.API_URL + "staff/update";
    $.ajax({
        type: "PUT",
        url: url,
        contentType: "application/json",
        dataType: "json",
        data: JSON.stringify(data)
    }).done(doneCallback).fail(failCallback).always(alwaysCallback);
};
DonexApp.Api.getStaff = function (staffId, doneCallback, failCallback, alwaysCallback) {
    var url = DonexApp.Api.Constants.API_URL + "staff/get?staffId=" + encodeURIComponent(staffId);
    $.ajax({
        type: "GET",
        url: url,
        contentType: "application/json",
        dataType: "json"
    }).done(doneCallback).fail(failCallback).always(alwaysCallback);
};
DonexApp.Api.deleteStaff = function (staffId, doneCallback, failCallback, alwaysCallback) {
    var url = DonexApp.Api.Constants.API_URL + "staff/delete/" + encodeURIComponent(staffId);
    $.ajax({
        type: "DELETE",
        url: url,
        contentType: "application/json",
        dataType: "json"
    }).done(doneCallback).fail(failCallback).always(alwaysCallback);
};
DonexApp.Api.getInferiorStaff = function (staffId, successCallback, errorCallback, alwaysCallback) {
    var url = DonexApp.Api.Constants.API_URL + "staff/getInferiorStaff";
    if (staffId !== undefined) {
        url = url + "?staffId=" + encodeURIComponent(staffId);
    }

    $.ajax({
        type: "GET",
        url: url,
        contentType: "application/json",
        dataType: "json"
    }).done(successCallback).fail(errorCallback).always(alwaysCallback);
};
DonexApp.Api.login = function (staffId, password, doneCallback, failCallback, alwaysCallback) {
    var url = DonexApp.Api.Constants.API_URL + "login";
    var saveUserInfo = function (data, textStatus, jqXHR) {
        if (data.code == DonexApp.Api.RESPONSE_CODE.SUCCESS) {
            var userInfo = data.data;
            userInfo.password = null;
            userInfo.token = null;
            $.cookie("UserInfo", JSON.stringify(userInfo));
        }
        if ($.isFunction(doneCallback)) {
            doneCallback(data, textStatus, jqXHR);
        }
    };
    $.ajax({
        type: "POST",
        url: url,
        contentType: "application/json",
        dataType: "json",
        data: JSON.stringify({"staffId": staffId, "password": password})
    }).done(saveUserInfo).fail(failCallback).always(alwaysCallback);
};
DonexApp.Api.logout = function (doneCallback, failCallback, alwaysCallback) {
    var url = DonexApp.Api.Constants.API_URL + "logout";
    $.removeCookie("UserInfo");
    $.ajax({
        type: "POST",
        url: url,
        contentType: "application/json",
        dataType: "json"
    }).done(doneCallback).fail(failCallback).always(alwaysCallback);
};
DonexApp.Api.getAllGoods = function (successCallback, errorCallback, alwaysCallback, page, size) {
    var url = DonexApp.Api.Constants.API_URL + "goods/getall";
    if (page !== undefined && size !== undefined) {
        url += "?page=" + encodeURIComponent(page) + "&size=" + encodeURIComponent(size);
    }

    $.ajax({
        type: "GET",
        url: url,
        contentType: "application/json",
        dataType: "json"
    }).done(successCallback).fail(errorCallback).always(alwaysCallback);
};
DonexApp.Api.deleteGoods = function (goodsId, doneCallback, failCallback, alwaysCallback) {
    var url = DonexApp.Api.Constants.API_URL + "goods/delete/" + encodeURIComponent(goodsId);
    $.ajax({
        type: "DELETE",
        url: url,
        contentType: "application/json",
        dataType: "json"
    }).done(doneCallback).fail(failCallback).always(alwaysCallback);
};
DonexApp.Api.addGoods = function (data, doneCallback, failCallback, alwaysCallback) {
    var url = DonexApp.Api.Constants.API_URL + "goods/add";
    $.ajax({
        type: "POST",
        url: url,
        contentType: "application/json",
        dataType: "json",
        data: JSON.stringify(data)
    }).done(doneCallback).fail(failCallback).always(alwaysCallback);
};
DonexApp.Api.uploadGoodsAvatar = function (goodsId, fileInput, doneCallback, failCallback, alwaysCallback) {
    var url = DonexApp.Api.Constants.API_URL + "file/goods_image";

    var formData = new FormData($("<form enctype='multipart/form-data'></form>")[0]);
    formData.append("goodId", goodsId); // TODO server use incorrect grammar
    formData.append("file", fileInput.files[0]);

    $.ajax({
        type: "POST",
        url: url,
        data: formData,
        dataType: 'json',
        cache: false,
        contentType: false,
        processData: false
    }).done(doneCallback).fail(failCallback).always(alwaysCallback);
};
DonexApp.Api.getGoods = function (goodsId, doneCallback, failCallback, alwaysCallback) {
    var url = DonexApp.Api.Constants.API_URL + "goods/get?id=" + encodeURIComponent(goodsId);
    $.ajax({
        type: "GET",
        url: url,
        contentType: "application/json",
        dataType: "json"
    }).done(doneCallback).fail(failCallback).always(alwaysCallback);
};
DonexApp.Api.updateGoods = function (data, doneCallback, failCallback, alwaysCallback) {
    var url = DonexApp.Api.Constants.API_URL + "goods/update";
    $.ajax({
        type: "PUT",
        url: url,
        contentType: "application/json",
        dataType: "json",
        data: JSON.stringify(data)
    }).done(doneCallback).fail(failCallback).always(alwaysCallback);
};
DonexApp.Api.getAllCustomer = function (successCallback, errorCallback, alwaysCallback, page, size) {
    var url = DonexApp.Api.Constants.API_URL + "customer/getall";
    if (page !== undefined && size !== undefined) {
        url += "?page=" + encodeURIComponent(page) + "&size=" + encodeURIComponent(size);
    }

    $.ajax({
        type: "GET",
        url: url,
        contentType: "application/json",
        dataType: "json"
    }).done(successCallback).fail(errorCallback).always(alwaysCallback);
};
DonexApp.Api.deleteCustomer = function (customerId, doneCallback, failCallback, alwaysCallback) {
    var url = DonexApp.Api.Constants.API_URL + "customer/delete/" + encodeURIComponent(customerId);
    $.ajax({
        type: "DELETE",
        url: url,
        contentType: "application/json",
        dataType: "json"
    }).done(doneCallback).fail(failCallback).always(alwaysCallback);
};
DonexApp.Api.addCustomer = function (data, doneCallback, failCallback, alwaysCallback) {
    var url = DonexApp.Api.Constants.API_URL + "customer/add";
    $.ajax({
        type: "POST",
        url: url,
        contentType: "application/json",
        dataType: "json",
        data: JSON.stringify(data)
    }).done(doneCallback).fail(failCallback).always(alwaysCallback);
};
DonexApp.Api.uploadCustomerAvatar = function (customerId, fileInput, doneCallback, failCallback, alwaysCallback) {
    var url = DonexApp.Api.Constants.API_URL + "file/customer_avatar";

    var formData = new FormData($("<form enctype='multipart/form-data'></form>")[0]);
    formData.append("customerId", customerId);
    formData.append("file", fileInput.files[0]);

    $.ajax({
        type: "POST",
        url: url,
        data: formData,
        dataType: 'json',
        cache: false,
        contentType: false,
        processData: false
    }).done(doneCallback).fail(failCallback).always(alwaysCallback);
};
DonexApp.Api.getCustomer = function (customerId, doneCallback, failCallback, alwaysCallback) {
    var url = DonexApp.Api.Constants.API_URL + "customer/get?customerId=" + encodeURIComponent(customerId);
    $.ajax({
        type: "GET",
        url: url,
        contentType: "application/json",
        dataType: "json"
    }).done(doneCallback).fail(failCallback).always(alwaysCallback);
};
DonexApp.Api.updateCustomer = function (data, doneCallback, failCallback, alwaysCallback) {
    var url = DonexApp.Api.Constants.API_URL + "customer/update";
    $.ajax({
        type: "PUT",
        url: url,
        contentType: "application/json",
        dataType: "json",
        data: JSON.stringify(data)
    }).done(doneCallback).fail(failCallback).always(alwaysCallback);
};
DonexApp.Api.getAllLevel = function (successCallback, errorCallback, alwaysCallback) {
    var url = DonexApp.Api.Constants.API_URL + "level/getall";
    $.ajax({
        type: "GET",
        url: url,
        contentType: "application/json",
        dataType: "json"
    }).done(successCallback).fail(errorCallback).always(alwaysCallback);
};
DonexApp.Api.addLevel = function (data, doneCallback, failCallback, alwaysCallback) {
    var url = DonexApp.Api.Constants.API_URL + "level/add";
    $.ajax({
        type: "POST",
        url: url,
        contentType: "application/json",
        dataType: "json",
        data: JSON.stringify(data)
    }).done(doneCallback).fail(failCallback).always(alwaysCallback);
};
DonexApp.Api.updateLevel = function (data, doneCallback, failCallback, alwaysCallback) {
    var url = DonexApp.Api.Constants.API_URL + "level/update";
    $.ajax({
        type: "PUT",
        url: url,
        contentType: "application/json",
        dataType: "json",
        data: JSON.stringify(data)
    }).done(doneCallback).fail(failCallback).always(alwaysCallback);
};
// .API

// LOGIN LOGOUT

// . LOGIN LOGOUT

// INIT
// Setup ajax
$.ajaxSetup({
    xhrFields: {
        withCredentials: true
    }
});
// Check login
var checkLoginAndRedirect = function () {
    if ($.cookie("UserInfo") !== undefined) {
        var userInfo = JSON.parse($.cookie("UserInfo"));
        var staffId = userInfo.staffId;
        if (staffId !== undefined && staffId != null) {
            DonexApp.Api.getStaff(staffId,
                function () {
                },
                function (data) {
                    if (data.status == 403 || data.status == 401) {
                        window.location = "login.jsp";
                    }
                },
                function () {
                }
            );
        } else {
            window.location = "login.jsp";
        }
    } else {
        window.location = "login.jsp";
    }
};
if (!window.location.pathname.match(/.*login\.jsp$/)) {
    checkLoginAndRedirect();
}
