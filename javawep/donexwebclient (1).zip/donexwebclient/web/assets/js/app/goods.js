$(document).ready(function () {
    /******************************** MÀN HÌNH THÔNG TIN ********************************/
    var showGoodsInfo = function () {
        var goodsId = $(this).attr("goodsId");

        if (window.GOODS_INFO_SCREEN === undefined) {
            window.GOODS_INFO_SCREEN = {};
        }
        window.GOODS_INFO_SCREEN.goodsId = goodsId;

        var goods = window.goodsMap[goodsId];
        if (goods !== undefined) {
            $("#app-goods-info-id").text(goods.goodsId == null ? "" : goods.goodsId);
            $("#app-goods-info-name").text(goods.name == null ? "" : goods.name);
            $("#app-goods-info-unit").text(goods.unit == null ? "" : goods.unit);
            $("#app-goods-info-price").text(goods.price == null ? "" : goods.price);
            if (goods.category != null) {
                var categoryString = "";
                $.each(goods.category, function (index, value) {
                    categoryString += value + ",";
                });
                if (categoryString.length > 0) {
                    sizeString = categoryString.substr(0, categoryString.length - 1);
                }
                $("#app-goods-info-category").text(categoryString);
            } else {
                $("#app-goods-info-category").text("");
            }
            $("#app-goods-info-color").text(goods.color == null ? "" : goods.color);
            if (goods.sizes != null) {
                var sizeString = "";
                $.each(goods.sizes, function (index, value) {
                    sizeString += value + ",";
                });
                sizeString = sizeString.substr(0, sizeString.length - 1);
                $("#app-goods-info-size").text(sizeString);
            } else {
                $("#app-goods-info-size").text("");
            }

            if (goods.imageId != null) {
                $("#app-goods-info-avatar").attr("src", DonexApp.Api.Constants.API_IMAGE_URL + goods.imageId);
            } else {
                $("#app-goods-info-avatar").attr("src", "assets/img/app/missing-avatar.jpg");
            }
        }
        $(".app-container").hide();
        $("#app-goods-info-container").show();
    };
    // Nhấn nút quay lại màn hình list từ màn hình info
    $("#app-back-to-goods-list").click(function () {
        $(".app-container").hide();
        $("#app-goods-list-container").show();
    });
    // Nhấn nút chỉnh sửa thông tin sản phẩm
    $("#app-edit-goods").click(function () {
        window.location.href = "edit-goods.jsp?goodsId=" + encodeURIComponent(window.GOODS_INFO_SCREEN.goodsId);
    });
    // Nhấn nút xóa sản phẩm
    $("#app-delete-goods").click(function () {
        DonexApp.Control.showRedYesNoDialog("Bạn có chắc muốn xóa sản phẩm này?", function () {
            DonexApp.Control.showLoading();
            DonexApp.Api.deleteGoods(window.GOODS_INFO_SCREEN.goodsId,
                function (data) {
                    if (data.code == DonexApp.Api.RESPONSE_CODE.SUCCESS) {
                        DonexApp.Control.showOkDialog("Sản phẩm này đã bị xóa!", function () {
                            window.location = "goods.jsp";
                        });
                    } else {
                        DonexApp.Control.showRedOkDialog("Có lỗi xảy ra, hiện chưa xóa được sản phẩm này! Vui lòng thử lại sau.");
                    }
                },
                function () {
                    DonexApp.Control.showRedOkDialog("Có lỗi xảy ra, hiện chưa xóa được sản phẩm này! Vui lòng thử lại sau.");
                },
                function () {
                    DonexApp.Control.hideLoading();
                });
        });
    });

    /******************************** MÀN HÌNH LIST ********************************/
    var displayGoodsList = function (goodsList) {
        var $table = $("table.app-fragment").clone();
        $table.attr("id", "app-goods-list-table").removeClass("app-fragment");
        $table[0].listData = goodsList;
        $table[0].showTableData = function (fromItemIndex, toItemIndex) {
            // Đổ dữ liệu vào bảng
            var $table = $(this);
            var $tbody = $table.find("tbody").empty();
            var $thead = $table.find("thead").empty();

            var listData = $table[0].listData;

            $thead.append("<tr><th style='width: 0.8cm;'>#</th><th style='width: 1cm;'></th><th>Mã sản phẩm</th><th>Tên</th><th>Giá</th><th>Đơn vị tính</th><th style='width: 0.8cm;'>&nbsp;</th></tr>");

            for (var index = fromItemIndex; index <= toItemIndex; index++) {
                var data = listData[index - 1];
                var $row = $("<tr></tr>");
                var $avatarColumn = $("<td></td>");
                var $avatarImage = $("<img style='width: 1.5cm; height: 1.5cm; border-radius: 0.3cm;' />");
                $avatarColumn.append($avatarImage);
                if (data.imageId != null) {
                    $avatarImage.attr("src", DonexApp.Api.Constants.API_IMAGE_URL + data.imageId);
                } else {
                    $avatarImage.attr("src", "assets/img/app/missing-avatar.jpg");
                }
                var $goodsIdColumn = $("<td></td>").text(data.goodsId == null ? "" : data.goodsId);
                var $nameColumn = $("<td></td>").text(data.name == null ? "" : data.name);
                var $unitColumn = $("<td></td>");
                $unitColumn.text(data.unit == null ? "" : data.unit);
                var $priceColumn = $("<td></td>").text(data.price == null ? "" : data.price);
                $row.append("<td>" + index + "</td>")
                    .append($avatarColumn)
                    .append($goodsIdColumn)
                    .append($nameColumn)
                    .append($priceColumn)
                    .append($unitColumn);
                $row.append($("<td></td>").append(
                    $("<button class='btn app-goods-info-button'><i class='glyphicon glyphicon-user'>&nbsp;</i>Xem chi tiết</button>")
                        .attr("goodsId", data.goodsId)
                        .unbind().click(showGoodsInfo))
                );
                $tbody.append($row);
            }
        };

        // Hiển thị bảng và nút phân trang
        var $container = $("#app-goods-list-container").empty();
        var $pagination = DonexApp.Utils.createPagination($table, function (fromIndex, toIndex) {
            $table[0].showTableData(fromIndex, toIndex);
        });
        $container.append($pagination);
        $container.append($table);
        $($pagination.find("[app-index=1]")).click();
    };

    var displayErrorGoodsList = function (message) {
        var $container = $("#app-goods-list-container").empty();
        $container.append(
            $("<div class='alert alert-danger'></div>").text(
                message === undefined ? "Có sự cố về mạng hoặc máy chủ. Vui lòng thử lại sau!" : message
            ));
    };

    // Vào màn hình all goods
    DonexApp.Control.showLoading();
    DonexApp.Api.getAllGoods(
        function (response) {
            if (response.code == 0) {
                var goodsList = response.data;
                // Lưu dữ liệu list staff vào màn hình này
                window.goodsMap = {};
                $(goodsList).each(function (index, value) {
                    if (value.goodsId != null) {
                        window.goodsMap[value.goodsId] = value;
                    }
                });
                displayGoodsList(goodsList);
            }
        },
        function (data) {
            displayErrorGoodsList(data.statusText);
        },
        function () {
            DonexApp.Control.hideLoading();
        },
        0,
        999 // TODO change page and size
    );
});