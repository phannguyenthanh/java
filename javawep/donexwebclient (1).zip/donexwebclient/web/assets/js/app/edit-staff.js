$(document).ready(function () {
    /** Chỉnh lại một chút các input **/
    $(".app-input-date").datepicker({
        yearRange: "-90:+0",
        changeYear: true,
        dateFormat: 'dd/mm/yy',
        defaultDate: '01/01/1990'
    });
    var setupLevelInput = function () {
        var $inputLevel = $("#input-level");
        $inputLevel.empty();
        $inputLevel.append("<option value='' style='font-style: italic; color: lightgray;'>(Bỏ trống)</option>");
        $.each(window.allLevel, function (index, levelObject) {
            var $option = $("<option></option>");
            $option.attr("value", levelObject.level).text(levelObject.levelName);
            $inputLevel.append($option);
        });

        // ---> Next task
        pullStaffDataToForm();
    };
    var setupSuperiorStaffInput = function () {
        var $inputSuperiorStaff = $("#input-superior-staff-id");
        $inputSuperiorStaff.empty();

        $inputSuperiorStaff.append("<option value='' style='font-style: italic; color: lightgray;'>(Bỏ trống)</option>");

        var currentLoginStaff = DonexApp.Utils.getCurrentLoginStaff();
        $inputSuperiorStaff.append($("<option></option>").val(currentLoginStaff.staffId).text(currentLoginStaff.staffId + " (" + currentLoginStaff.name + ")"));

        $.each(window.allStaff, function (index, staffObject) {
            var $option = $("<option></option>");
            $option.attr("value", staffObject.staffId).text(staffObject.staffId + " (" + staffObject.name + ")");
            $inputSuperiorStaff.append($option);
        });

        // Ô nhập để tìm kiếm nhanh
        var $helper = $("#input-superior-staff-id-helper");
        $helper.unbind("change").on('change', function () {
            var terms = $helper.val().split(/\s+/);

            // Xem có match với user nào mình đang quản lý không
            $inputSuperiorStaff.find("option").each(function (index, inputOption) {
                var $inputOption = $(inputOption);
                if ($inputOption.val() != "") {
                    var searchText = $inputOption.text();
                    var matched = true;
                    for (var termIndex = 0; termIndex < terms.length; termIndex++) {
                        if (DonexApp.Utils.removeVietnameseToneMark(searchText.toLowerCase())
                                .indexOf(DonexApp.Utils.removeVietnameseToneMark(terms[termIndex])) <= -1) {
                            matched = false;
                            break;
                        }
                    }
                    if (matched) {
                        $(inputOption).show();
                    } else {
                        $(inputOption).hide();
                    }
                }
            });
        });

        // ------- Next task
        downloadLevelInformation();
    };

    /** Tải dữ liệu lên server **/
    // Nhấn nút cập nhật avatar
    $("#input-submit-edit-avatar").click(function () {
        var inputFile = $("#input-staff-avatar")[0];

        if (inputFile.value == "") {
            DonexApp.Control.showOkDialog("Bạn phải chọn file ảnh để cập nhật!");
        } else if (inputFile.files[0].size >= DonexApp.Config.MAX_FILE_SIZE) {
            DonexApp.Control.showOkDialog("Bạn phải chọn file ảnh có kích thước nhỏ hơn " + (DonexApp.Config.MAX_FILE_SIZE / 1024) + "KB để cập nhật!");
        } else {
            DonexApp.Control.showLoading();
            DonexApp.Api.uploadStaffAvatar(staff.staffId, inputFile,
                function (response) {
                    if (response.code == DonexApp.Api.RESPONSE_CODE.SUCCESS) {
                        DonexApp.Control.showOkDialog("Cập nhật thành công avatar!");
                        window.staff.avatarId = response.data.avatarId;
                        if (window.staff.avatarId !== undefined && window.staff.avatarId != null && window.staff.avatarId != "") {
                            $("#app-staff-avatar").attr("src", DonexApp.Api.Constants.API_IMAGE_URL + window.staff.avatarId);
                        }
                    } else {
                        DonexApp.Control.showRedOkDialog("Vui lòng chọn 1 bức ảnh đúng như yêu cầu!");
                    }
                },
                function () {
                    DonexApp.Control.showRedOkDialog("Có lỗi xảy ra! Avatar chưa được cập nhật. Vui lòng thử lại sau.");
                },
                function () {
                    DonexApp.Control.hideLoading();
                }
            );
        }
        return false;
    });

    // Nhấn nút cập nhật thông tin nhân viên
    $("#input-submit-edit").click(function () {

        // staff id
        if ($.trim($("#input-staff-id").val()) == "") {
            DonexApp.Control.showRedOkDialog("Mã nhân viên không được bỏ trống", function () {
                $("#input-staff-id").focus();
            });
            return false;
        }

        // email
        var $inputStaffEmail = $("#input-email");
        var inputStaffEmailVal = $.trim($inputStaffEmail.val());
        if (inputStaffEmailVal != "" && !DonexApp.Constants.EMAIL_REGEX.test(inputStaffEmailVal)) {
            DonexApp.Control.showRedOkDialog("Vui lòng nhập đúng định dạng địa chỉ email", function () {
                $inputStaffEmail.focus();
            });
            return false;
        }

        //
        var newStaff = {};

        newStaff.staffId = $("#input-staff-id").val();
        newStaff.superiorStaffId = $("#input-superior-staff-id").val();
        newStaff.name = $("#input-staff-name").val();
        newStaff.dateOfBirth = getDateFromFormat($("#input-date-of-birth").val(), "dd/MM/yyyy");
        newStaff.level = $("#input-level").val();
        newStaff.mobile = $("#input-mobile").val();
        newStaff.alternativeMobile = $("#input-alternative-mobile").val();
        newStaff.email = $("#input-email").val();
        newStaff.cmnd = $("#input-cmnd").val();
        newStaff.permanentAddress = $("#input-permanent-address").val();
        newStaff.livingAddress = $("#input-living-address").val();
        newStaff.startWorkingDate = getDateFromFormat($("#input-start-working-date").val(), "dd/MM/yyyy");
        newStaff.endWorkingDate = getDateFromFormat($("#input-end-working-date").val(), "dd/MM/yyyy");
        newStaff.employmentStatus = $("#input-employment-status").val();

        if (newStaff.dateOfBirth == 0) {
            newStaff.dateOfBirth = null;
        }
        if (newStaff.startWorkingDate == 0) {
            newStaff.startWorkingDate = null;
        }
        if (newStaff.endWorkingDate == 0) {
            newStaff.endWorkingDate = null;
        }
        $.each(newStaff, function (key, value) {
            if (value != null) {
                if (($.trim(value).length == 0 && (staff[key] == null || staff[key] === undefined)) || $.trim(value) == staff[key]) {
                    newStaff[key] = null;
                } else {
                    newStaff[key] = $.trim(value);
                }
            }
        });
        // Không sửa staffId
        newStaff.staffId = staff.staffId;

        DonexApp.Control.showLoading();
        DonexApp.Api.updateStaff(newStaff,
            function (data) {
                if (data.code == DonexApp.Api.RESPONSE_CODE.SUCCESS) {
                    DonexApp.Control.showOkDialog("Đã cập nhật!", function () {
                        location.reload();
                    });
                } else if (data.code == DonexApp.Api.RESPONSE_CODE.NOT_EXISTED_STAFF) {
                    DonexApp.Control.showRedOkDialog("Không tồn tại nhân viên với mã (" + staff.staffId + ") trong cơ sở dữ liệu. Mời bạn chọn lại nhân viên.", function () {
                        window.location = "staff.jsp";
                    });
                }
            },
            function () {
                DonexApp.Control.showRedOkDialog("Có lỗi xảy ra. Vui lòng thử lại sau.", function () {
                    window.location = "index.jsp";
                });
            },
            function () {
                DonexApp.Control.hideLoading();
            }
        );

        return false;
    });

    /** Tải dữ liệu cần thiết từ trên server **/

    var pullStaffDataToForm = function () {
        $("#input-staff-id").val(staff.staffId == null ? "" : staff.staffId);
        $("#input-superior-staff-id").val(staff.superiorStaffId == null ? "" : staff.superiorStaffId);
        $("#input-staff-name").val(staff.name == null ? "" : staff.name);
        $("#input-date-of-birth").val(staff.dateOfBirth == null ? "" : DonexApp.Utils.timestampToShortDateString(staff.dateOfBirth));
        $("#input-level").val(staff.level == null ? "" : staff.level);
        $("#input-mobile").val(staff.mobile == null ? "" : staff.mobile);
        $("#input-alternative-mobile").val(staff.alternativeMobile == null ? "" : staff.alternativeMobile);
        $("#input-email").val(staff.email == null ? "" : staff.email);
        $("#input-cmnd").val(staff.cmnd == null ? "" : staff.cmnd);
        $("#input-permanent-address").val(staff.permanentAddress == null ? "" : staff.permanentAddress);
        $("#input-living-address").val(staff.livingAddress == null ? "" : staff.livingAddress);
        $("#input-start-working-date").val(staff.startWorkingDate == null ? "" : DonexApp.Utils.timestampToShortDateString(staff.startWorkingDate));
        $("#input-end-working-date").val(staff.endWorkingDate == null ? "" : DonexApp.Utils.timestampToShortDateString(staff.endWorkingDate));
        $("#input-employment-status").val(staff.employmentStatus == null ? "" : staff.employmentStatus);

        if (staff.avatarId !== undefined && staff.avatarId != null && staff.avatarId != "") {
            $("#app-staff-avatar").attr("src", DonexApp.Api.Constants.API_IMAGE_URL + staff.avatarId);
        }
    };

    // Tải thông tin tất cả level của staff về
    var downloadLevelInformation = function () {
        DonexApp.Api.getAllLevel(
            function (response) {
                if (response.code == DonexApp.Api.RESPONSE_CODE.SUCCESS) {
                    window.allLevel = response.data;
                    if (window.allLevel == null) {
                        window.allLevel = [];
                    }
                    setupLevelInput();
                } else {
                    DonexApp.Control.showRedOkDialog("Có lỗi xảy ra. Vui lòng thử lại sau.", function () {
                        window.location = "index.jsp";
                    });
                }
            },
            function () {
                DonexApp.Control.showRedOkDialog("Có lỗi xảy ra với đường truyền internet hoặc server.\nVui lòng thử lại sau.", function () {
                    window.location.reload();
                });
            },
            function () {
                DonexApp.Control.hideLoading();
            }
        );
    };

    // Tải thông tin staff về
    window.parameters = DonexApp.Utils.getUrlParameters();
    var staffId = window.parameters["staffId"];
    if (staffId !== undefined && staffId.length > 0) {
        DonexApp.Control.showLoading();
        DonexApp.Api.getAllVisibleStaff(
            function (response) {
                if (response.code == DonexApp.Api.RESPONSE_CODE.SUCCESS) {
                    window.allStaff = response.data;
                    if (window.allStaff == null) {
                        window.allStaff = [];
                    }
                    window.staff = undefined;
                    for (var i = 0; i < window.allStaff.length; i++) {
                        if (window.allStaff[i].staffId == staffId) {
                            window.staff = window.allStaff[i];
                            break;
                        }
                    }
                    if (window.staff !== undefined) {
                        setupSuperiorStaffInput();
                    } else {
                        DonexApp.Control.hideLoading();
                        DonexApp.Control.showRedOkDialog("Không tìm thấy nhân viên này (có thể là vừa mới bị xóa?)", function () {
                            window.location = "staff.jsp";
                        });
                    }
                } else {
                    DonexApp.Control.hideLoading();
                    DonexApp.Control.showRedOkDialog("Có lỗi xảy ra. Vui lòng thử lại sau.", function () {
                        window.location = "index.jsp";
                    });
                }
            },
            function () {
                DonexApp.Control.hideLoading();
                DonexApp.Control.showRedOkDialog("Có lỗi xảy ra với đường truyền internet hoặc server.\nVui lòng thử lại sau.", function () {
                    window.location.reload();
                });
            },
            function () {
            },
            0,
            999999 // TODO change this
        );
        /*DonexApp.Api.getStaff(staffId,
         function (response) {
         if (response.code == DonexApp.Api.RESPONSE_CODE.SUCCESS) {
         window.staff = response.data;
         pullStaffDataToForm();
         setupSuperiorStaffInput();
         downloadLevelInformation();
         } else if (response.code == DonexApp.Api.RESPONSE_CODE.NOT_EXISTED) {
         DonexApp.Control.hideLoading();
         DonexApp.Control.showRedOkDialog("Không tìm thấy nhân viên này (có thể là vừa mới bị xóa?)", function () {
         window.location = "staff.jsp";
         });
         } else {
         DonexApp.Control.hideLoading();
         DonexApp.Control.showRedOkDialog("Có lỗi xảy ra. Vui lòng thử lại sau.", function () {
         window.location = "staff.jsp";
         });
         }
         },
         function () {
         DonexApp.Control.hideLoading();
         DonexApp.Control.showRedOkDialog("Có lỗi xảy ra với đường truyền internet hoặc server. Vui lòng thử lại sau.", function () {
         window.location = "staff.jsp";
         });
         },
         function () {
         });*/
    } else {
        window.location = "staff.jsp";
    }

    /********************************  ********************************/

});