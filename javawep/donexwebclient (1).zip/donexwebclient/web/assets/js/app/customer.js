$(document).ready(function () {
    /******************************** MÀN HÌNH THÔNG TIN ********************************/
    var showCustomerInfo = function () {
        var customerId = $(this).attr("customerId");

        if (window.CUSTOMER_INFO_SCREEN === undefined) {
            window.CUSTOMER_INFO_SCREEN = {};
        }
        window.CUSTOMER_INFO_SCREEN.customerId = customerId;

        var customer = window.customerMap[customerId];
        if (customer !== undefined) {
            $("#app-customer-info-id").text(customer.customerId == null ? "" : customer.customerId);
            $("#app-customer-info-name").text(customer.customerName == null ? "" : customer.customerName);
            $("#app-customer-info-vicegerent").text(customer.vicegerent == null ? "" : customer.vicegerent);
            $("#app-customer-info-vicegerent-info").text(customer.vicegerentInfo == null ? "" : customer.vicegerentInfo);
            $("#app-customer-info-address").text(customer.address == null ? "" : customer.address);
            $("#app-customer-info-tax-code").text(customer.taxCode == null ? "" : customer.taxCode);
            var phoneString = (customer.phone == null ? customer.mobile : customer.phone);
            $("#app-customer-info-phone").text(phoneString == null ? "" : phoneString);
            $("#app-customer-info-email").text(customer.email == null ? "" : customer.email);
            $("#app-customer-info-bank-account-number").text(customer.bankAccountNumber == null ? "" : customer.bankAccountNumber);
            var groupTagString = "";
            if (customer.groupTag != null && customer.groupTag !== undefined) {
                $.each(customer.groupTag, function (index, value) {
                    groupTagString += value + ", ";
                });
            }
            if (groupTagString.length > 2) {
                groupTagString = groupTagString.substr(0, groupTagString.length - 2);
            }
            $("#app-customer-info-group-tag").text(groupTagString);
            $("#app-customer-info-staff").text(customer.staffId == null ? "" : customer.staffId);

            if (customer.imageId != null) {
                $("#app-customer-info-avatar").attr("src", DonexApp.Api.Constants.API_IMAGE_URL + customer.imageId);
            } else {
                $("#app-customer-info-avatar").attr("src", "assets/img/app/missing-avatar.jpg");
            }
        }
        $(".app-container").hide();
        $("#app-customer-info-container").show();
    };
    // Nhấn nút quay lại màn hình list từ màn hình info
    $("#app-back-to-customer-list").click(function () {
        $(".app-container").hide();
        $("#app-customer-list-container").show();
    });
    // Nhấn nút chỉnh sửa thông tin sản phẩm
    $("#app-edit-customer").click(function () {
        window.location.href = "edit-customer.jsp?customerId=" + encodeURIComponent(window.CUSTOMER_INFO_SCREEN.customerId);
    });
    // Nhấn nút xóa sản phẩm
    $("#app-delete-customer").click(function () {
        DonexApp.Control.showRedYesNoDialog("Bạn có chắc muốn xóa khách hàng này khỏi danh sách?", function () {
            DonexApp.Control.showLoading();
            DonexApp.Api.deleteCustomer(window.CUSTOMER_INFO_SCREEN.customerId,
                function (data) {
                    if (data.code == DonexApp.Api.RESPONSE_CODE.SUCCESS) {
                        DonexApp.Control.showOkDialog("Khách hàng này đã bị xóa!", function () {
                            window.location = "customer.jsp";
                        });
                    } else {
                        DonexApp.Control.showRedOkDialog("Có lỗi xảy ra, hiện chưa xóa được khách hàng này! Vui lòng thử lại sau.");
                    }
                },
                function () {
                    DonexApp.Control.showRedOkDialog("Có lỗi xảy ra, hiện chưa xóa được khách hàng này! Vui lòng thử lại sau.");
                },
                function () {
                    DonexApp.Control.hideLoading();
                });
        });
    });

    /******************************** MÀN HÌNH LIST ********************************/
    var displayCustomerList = function (customerList) {
        var $table = $("table.app-fragment").clone();
        $table.attr("id", "app-customer-list-table").removeClass("app-fragment");
        $table[0].listData = customerList;
        $table[0].showTableData = function (fromItemIndex, toItemIndex) {
            // Đổ dữ liệu vào bảng
            var $table = $(this);
            var $tbody = $table.find("tbody").empty();
            var $thead = $table.find("thead").empty();

            var listData = $table[0].listData;

            $thead.append("<tr><th style='width: 0.8cm;'>#</th><th style='width: 1cm;'></th><th>Tên</th><th>Địa chỉ</th><th>Người đại diện</th><th>Mã nhân viên quản lý</th><th style='width: 0.8cm;'>&nbsp;</th></tr>");

            for (var index = fromItemIndex; index <= toItemIndex; index++) {
                var data = listData[index - 1];
                var $row = $("<tr></tr>")
                var $avatarColumn = $("<td></td>");
                var $avatarImage = $("<img style='width: 1cm; height: 1cm;' />");
                $avatarColumn.append($avatarImage);
                if (data.imageId != null) {
                    $avatarImage.attr("src", DonexApp.Api.Constants.API_IMAGE_URL + data.imageId);
                } else {
                    $avatarImage.attr("src", "assets/img/app/missing-avatar.jpg");
                }
                var $nameColumn = $("<td></td>").text(data.customerName == null ? "" : data.customerName);
                var $addressColumn = $("<td></td>").text(data.address == null ? "" : data.address);
                var $vicegerentColumn = $("<td></td>").text(data.vicegerent == null ? "" : data.vicegerent);
                var $staffIdColumn = $("<td></td>").text(data.staffId == null ? "" : data.staffId);
                $row.append("<td>" + index + "</td>").append($avatarColumn).append($nameColumn).append($addressColumn).append($vicegerentColumn).append($staffIdColumn);
                $row.append($("<td></td>").append(
                    $("<button class='btn app-customer-info-button'><i class='glyphicon glyphicon-user'>&nbsp;</i>Xem chi tiết</button>")
                        .attr("customerId", data.customerId)
                        .unbind().click(showCustomerInfo))
                );
                $tbody.append($row);
            }
        };

        // Hiển thị bảng và nút phân trang
        var $container = $("#app-customer-list-container").empty();
        var $pagination = DonexApp.Utils.createPagination($table, function (fromIndex, toIndex) {
            $table[0].showTableData(fromIndex, toIndex);
        });
        $container.append($pagination);
        $container.append($table);
        $($pagination.find("[app-index=1]")).click();
    };

    var displayErrorCustomerList = function (message) {
        var $container = $("#app-customer-list-container").empty();
        $container.append(
            $("<div class='alert alert-danger'></div>").text(
                message === undefined ? "Có sự cố về mạng hoặc máy chủ. Vui lòng thử lại sau!" : message
            ));
    };

    // Vào màn hình all
    DonexApp.Control.showLoading();
    DonexApp.Api.getAllCustomer(
        function (response) {
            if (response.code == 0) {
                var customerList = response.data;
                // Lưu dữ liệu list vào màn hình này
                window.customerMap = {};
                $(customerList).each(function (index, value) {
                    if (value.customerId != null) {
                        window.customerMap[value.customerId] = value;
                    }
                });
                displayCustomerList(customerList);
            }
        },
        function (data) {
            displayErrorCustomerList(data.statusText);
        },
        function () {
            DonexApp.Control.hideLoading();
        },
        0,
        999 // TODO change page and size
    );
});