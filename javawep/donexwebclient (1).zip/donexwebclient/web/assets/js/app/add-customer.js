$(document).ready(function () {
    /** Chỉnh lại một số input **/
    var setupStaffIdInput = function () {
        var $inputCustomerStaffId = $("#input-customer-staff-id");
        $inputCustomerStaffId.empty();

        $inputCustomerStaffId.append("<option value='' style='font-style: italic; color: lightgray;'>(Bỏ trống)</option>");

        var currentLoginStaff = DonexApp.Utils.getCurrentLoginStaff();
        if (currentLoginStaff.level == DonexApp.Constants.NVKD_LEVEL_NUMBER) {
            $inputCustomerStaffId.append($("<option></option>").val(currentLoginStaff.staffId).text(currentLoginStaff.staffId + " (" + currentLoginStaff.name + ")"));
        }

        $.each(window.allStaff, function (index, staffObject) {
            if (staffObject.level == DonexApp.Constants.NVKD_LEVEL_NUMBER) {
                var $option = $("<option></option>");
                $option.attr("value", staffObject.staffId).text(staffObject.staffId + " (" + staffObject.name + ")");
                $inputCustomerStaffId.append($option);
            }
        });

        // Ô nhập để tìm kiếm nhanh
        var $helper = $("#input-superior-staff-id-helper");
        $helper.unbind("change").on('change', function () {
            var terms = $helper.val().split(/\s+/);

            $inputCustomerStaffId.find("option").each(function (index, inputOption) {
                var $inputOption = $(inputOption);
                if ($inputOption.val() != "") {
                    var searchText = $inputOption.text();
                    var matched = true;
                    for (var termIndex = 0; termIndex < terms.length; termIndex++) {
                        if (DonexApp.Utils.removeVietnameseToneMark(searchText.toLowerCase())
                                .indexOf(DonexApp.Utils.removeVietnameseToneMark(terms[termIndex])) <= -1) {
                            matched = false;
                            break;
                        }
                    }
                    if (matched) {
                        $(inputOption).show();
                    } else {
                        $(inputOption).hide();
                    }
                }
            });
        });

        var removeTag = function () {
            $(this).parent().remove();
        };

        // Nhấn nút thêm group tag
        $("#input-customer-add-group-tag-button").unbind().click(function () {
            var $inputGroupTag = $("#input-customer-group-tag");
            var inputTagString = $.trim($inputGroupTag.val());
            if (inputTagString != "") {
                inputTagString = DonexApp.Utils.upperCaseBeginning(inputTagString);
                $inputGroupTag.val(inputTagString);

                var isExisted = false;
                $("#list-customer-group-tag").find(".app-tag").each(function (index, tagObject) {
                    if ($(tagObject).attr("value") == inputTagString) {
                        isExisted = true;
                        return false;
                    }
                });

                if (isExisted) {
                    DonexApp.Control.showOkDialog("Đã có group này rồi!", function () {
                        $inputGroupTag.select();
                    });
                } else {
                    var $tag = DonexApp.Control.makeTag(inputTagString, removeTag);
                    $tag.attr("value", inputTagString);
                    $("#list-customer-group-tag").append($tag);
                }
            }
        });
    };

    /**  **/
    // Bắt đầu tải lên thông tin
    var uploadAvatar = function (customerId, inputFile) {
        DonexApp.Api.uploadCustomerAvatar(customerId, inputFile,
            function (data) {
                if (data.code == DonexApp.Api.RESPONSE_CODE.SUCCESS) {
                    DonexApp.Control.showOkDialog("Đã thêm khách hàng (đại lý)!", function () {
                        window.location = "customer.jsp";
                    });
                } else {
                    DonexApp.Control.showOkDialog("Đã thêm khách hàng (đại lý)! Tuy nhiên ảnh đại diện chưa được cập nhật.", function () {
                        window.location = "customer.jsp";
                    });
                }
            },
            function () {
                DonexApp.Control.showOkDialog("Đã thêm khách hàng (đại lý)! Tuy nhiên ảnh đại diện chưa được cập nhật.", function () {
                    window.location = "customer.jsp";
                });
            },
            function () {
                DonexApp.Control.hideLoading();
            }
        );
    };
    $("#input-submit-add").click(function () {
        try {

            // Validate
            if ($("#input-customer-id").val() == "") {
                DonexApp.Control.showRedOkDialog("Mã khách hàng không được bỏ trống", function () {
                    $("#input-customer-id").focus();
                });
                return false;
            }
            // email
            var $inputEmail = $("#input-customer-email");
            var inputStaffEmailVal = $.trim($inputEmail.val());
            if (inputStaffEmailVal != "" && !DonexApp.Constants.EMAIL_REGEX.test(inputStaffEmailVal)) {
                DonexApp.Control.showRedOkDialog("Vui lòng nhập đúng định dạng địa chỉ email", function () {
                    $inputEmail.focus();
                });
                return false;
            }

            DonexApp.Control.showLoading();
            $("#app-alert-box").hide();

            var customer = {};

            customer.customerId = $("#input-customer-id").val();
            customer.customerName = $("#input-customer-name").val();
            customer.vicegerent = $("#input-customer-vicegerent").val();
            customer.vicegerentInfo = $("#input-customer-vicegerent-info").val();
            customer.address = $("#input-customer-address").val();
            customer.taxCode = $("#input-customer-tax-code").val();
            customer.mobile = $("#input-customer-mobile").val();
            customer.phone = $("#input-customer-phone").val();
            customer.email = $("#input-customer-email").val();
            customer.bankAccountNumber = $("#input-customer-bank-account-number").val();

            var staffIdParts = $("#input-customer-staff-id").val().split(/\s+\(/);
            if ($.isArray(staffIdParts) && staffIdParts.length > 0) {
                customer.staffId = staffIdParts[0];
            } else {
                customer.staffId = null;
            }

            $.each(customer, function (key, value) {
                if (key != "groupTag" && value != null) {
                    if ($.trim(value).length == 0) {
                        customer[key] = null;
                    } else {
                        customer[key] = $.trim(value);
                    }
                }
            });

            var groupTag = [];
            $("#list-customer-group-tag").find(".app-tag").each(function (index, appTag) {
                groupTag.push($(appTag).attr("value"));
            });
            if (groupTag.length > 0) {
                customer.groupTag = groupTag;
            } else {
                customer.groupTag = null;
            }

            DonexApp.Api.addCustomer(customer,
                function (data) {
                    if (data.code == DonexApp.Api.RESPONSE_CODE.SUCCESS) {
                        var inputFile = $("#input-customer-avatar");
                        if (inputFile.value != "") {
                            uploadAvatar(customer.customerId, inputFile[0]);
                        } else {
                            DonexApp.Control.showOkDialog("Đã thêm khách hàng!", function () {
                                window.location = "customer.jsp";
                            });
                        }
                    } else if (data.code == DonexApp.Api.RESPONSE_CODE.EXISTED) {
                        DonexApp.Control.hideLoading();
                        $("#app-alert-box").text("Đã tồn tại khách hàng với mã [" + customer.customerId + "] trong cơ sở dữ liệu. Mời bạn sử dụng mã khách hàng khác.").show();
                        $("#input-customer-id").focus();
                    }
                },
                function () {
                    DonexApp.Control.hideLoading();
                    $("#app-alert-box").text("Có lỗi xảy ra. Vui lòng thử lại sau.").show();
                },
                function () {
                });
        } catch (ex) {
            console.log(ex);
        }
        return false;
    });

    // Tải thông tin tất cả staff về
    DonexApp.Control.showLoading();
    DonexApp.Api.getAllVisibleStaff(
        function (response) {
            if (response.code == DonexApp.Api.RESPONSE_CODE.SUCCESS) {
                window.allStaff = response.data;
                if (window.allStaff == null) {
                    window.allStaff = [];
                }
                setupStaffIdInput();
            } else {
                DonexApp.Control.showRedOkDialog("Có lỗi xảy ra. Vui lòng thử lại sau.");
            }
        },
        function () {
            DonexApp.Control.showRedOkDialog("Có lỗi xảy ra với đường truyền internet hoặc server. Vui lòng thử lại sau.", function () {
                window.location.reload();
            })
        },
        function () {
            DonexApp.Control.hideLoading();
        }
    );
});